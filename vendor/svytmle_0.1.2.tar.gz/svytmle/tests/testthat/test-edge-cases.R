# regression tests for the adversarial-review findings (2026-06-10)

test_that("whole-sample analysis works on nested (NHANES-style) PSU ids", {
  # PSU ids repeat across strata; subset = NULL must not crash (the engine's
  # whole-sample variance path carries no nest, so the wrapper routes nested
  # ids through the domain path with an all-TRUE indicator)
  dat <- tiny_frame(H = 4L, J = 2L)
  dat$psu <- ((dat$cluster - 1L) %% 2L) + 1L     # ids 1-2 repeat per stratum
  des <- survey::svydesign(ids = ~psu, strata = ~strata, weights = ~weight,
                           data = dat, nest = TRUE)
  set.seed(21)
  fit <- svytmle(des, "Y", "A", c("x1", "x2"), learners = "SL.glm")
  expect_s3_class(fit, "svytmle")
  expect_true(is.finite(fit$results$b) && fit$results$se > 0)
  expect_identical(fit$results$df, fit$n_psu - fit$n_strata)
  # ... and the all-TRUE routing is numerically identical to the unique-id
  # whole-sample path for the primary arm (same data, same seed)
  des_u <- tiny_design(dat)                       # globally unique ids
  set.seed(21)
  fit_u <- svytmle(des_u, "Y", "A", c("x1", "x2"), learners = "SL.glm")
  expect_identical(fit$results$b, fit_u$results$b)
  expect_identical(fit$results$se, fit_u$results$se)
})

test_that("arms = 'cv' with a single learner errors instead of returning a malformed object", {
  des <- tiny_design()
  expect_error(svytmle(des, "Y", "A", c("x1", "x2"), learners = "SL.glm",
                       arms = "cv"),
               "multi-learner")
})

test_that("a lonely-PSU stratum is rejected up front with a named-stratum error", {
  dat <- tiny_frame(H = 4L, J = 2L)
  dat <- dat[!(dat$strata == 3L & dat$cluster == max(dat$cluster[dat$strata == 3L])), ]
  des <- survey::svydesign(ids = ~cluster, strata = ~strata,
                           weights = ~weight, data = dat)
  expect_error(svytmle(des, "Y", "A", c("x1", "x2"), learners = "SL.glm"),
               "only one PSU|contribute only one PSU")
})

test_that("duplicated covariate names are rejected", {
  des <- tiny_design()
  expect_error(svytmle(des, "Y", "A", c("x1", "x1", "x2"), learners = "SL.glm"),
               "duplicated")
})

test_that("outcome/treatment inside covariates, and identical outcome/treatment, error", {
  des <- tiny_design()
  expect_error(svytmle(des, "Y", "A", c("Y", "x1"), learners = "SL.glm"),
               "must not contain")
  expect_error(svytmle(des, "Y", "A", c("A", "x1"), learners = "SL.glm"),
               "must not contain")
  expect_error(svytmle(des, "Y", "Y", c("x1", "x2"), learners = "SL.glm"),
               "different columns")
})

test_that("a single encoded covariate column errors up front (engine needs >= 2)", {
  des <- tiny_design()
  expect_error(svytmle(des, "Y", "A", "x1", learners = "SL.glm"),
               "at least two")
})

test_that("positional ids in svydesign() are recovered (not silently row-level)", {
  dat <- tiny_frame()
  des <- survey::svydesign(~cluster, strata = ~strata, weights = ~weight,
                           data = dat)
  ext <- svytmle:::.design_extract(des)
  expect_identical(ext$source, "call")
  expect_identical(ext$cluster, dat$cluster)   # NOT seq_len(n)
  set.seed(2)
  fit_pos <- svytmle(des, "Y", "A", c("x1", "x2"), learners = "SL.glm")
  set.seed(2)
  fit_nam <- svytmle(tiny_design(dat), "Y", "A", c("x1", "x2"),
                     learners = "SL.glm")
  expect_identical(fit_pos$results$b, fit_nam$results$b)
  expect_identical(fit_pos$results$df, fit_nam$results$df)
})

test_that("confint accepts arm codes and unknown arms error clearly", {
  des <- tiny_design()
  set.seed(5)
  fit <- svytmle(des, "Y", "A", c("x1", "x2"), learners = "SL.glm")
  expect_identical(rownames(confint(fit, parm = "cf")), "Fully-Aware-CF")
  expect_error(confint(fit, parm = "cv"), "unknown arm")
})
