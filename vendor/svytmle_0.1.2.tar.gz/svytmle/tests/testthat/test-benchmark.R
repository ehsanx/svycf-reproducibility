# Variance-method (S35) and compute (S36) benchmarks.

test_that("variance_methods returns the frozen-EIF routes with the right shape", {
  skip_on_cran()
  pop <- make_population("standard", "simple", truth_M = 5e3L)
  obs <- draw_sample(pop, sample_seed = 7L)
  des <- survey::svydesign(ids = ~cluster, strata = ~strata,
                           weights = ~weight, data = obs)
  set.seed(1)
  fit <- suppressWarnings(svytmle(des, "Y", "A", c("L1", "L2", "L3", "L4"),
                                  learners = "SL.glm"))

  vm <- suppressWarnings(variance_methods(
    fit, methods = c("linearization", "jackknife", "subbootstrap"),
    subbootstrap_replicates = 50L, seed = 1))

  expect_s3_class(vm, "data.frame")
  expect_setequal(names(vm),
                  c("method", "refit", "se", "se_ratio", "ci_lo", "ci_hi", "df", "seconds"))
  expect_equal(nrow(vm), 3L)
  expect_true(all(vm$refit == "No"))
  # the linearization row is the ratio base
  lin <- vm[grepl("Linearization", vm$method), ]
  expect_equal(lin$se_ratio, 1, tolerance = 1e-8)
  # the jackknife of the frozen EIF reproduces the linearization SE
  jk <- vm[grepl("jackknife", vm$method), ]
  expect_equal(jk$se, lin$se, tolerance = 1e-6)
  # the point estimate is attached and matches the fit's CF estimate
  expect_equal(attr(vm, "estimate"),
               fit$results$b[match("Fully-Aware-CF", fit$results$method)],
               tolerance = 1e-10)
})

test_that("variance_methods errors helpfully for an absent arm / no design", {
  skip_on_cran()
  pop <- make_population("standard", "simple", truth_M = 5e3L)
  obs <- draw_sample(pop, sample_seed = 7L)
  des <- survey::svydesign(ids = ~cluster, strata = ~strata,
                           weights = ~weight, data = obs)
  set.seed(1)
  fit <- suppressWarnings(svytmle(des, "Y", "A", c("L1", "L2", "L3", "L4"),
                                  learners = "SL.glm"))   # cf arm only
  expect_error(variance_methods(fit, arm = "Non-Aware"), "not in this fit")
  expect_error(variance_methods(fit, methods = "bootstrap", B = 5),
               "needs the original `design`")
})

test_that("benchmark_compute times the requested estimator variants", {
  skip_on_cran()
  pop <- make_population("standard", "simple", truth_M = 5e3L)
  obs <- draw_sample(pop, sample_seed = 7L)
  des <- survey::svydesign(ids = ~cluster, strata = ~strata,
                           weights = ~weight, data = obs)
  bc <- suppressWarnings(benchmark_compute(
    des, "Y", "A", c("L1", "L2", "L3", "L4"),
    learners = "SL.glm", what = c("aipw", "rr_or"), seed = 1))

  expect_s3_class(bc, "data.frame")
  expect_true(all(c("estimator", "wall_s", "cpu_s", "ok") %in% names(bc)))
  expect_equal(nrow(bc), 2L)
  expect_true(all(bc$ok))
  expect_true(all(bc$wall_s >= 0))
})
