# nuisance_weights = c("unweighted", "survey") -- added 2026-09-24 ([PKG-EDIT] (4)).
# The default must be the reference estimator bit-for-bit; "survey" must use the
# survey weights (with the training-fold PSU-selection correction) and only them.

legacy <- function() {
  f <- testthat::test_path("fixtures", "ref_legacy_nuisance.rds")
  skip_if_not(file.exists(f), "legacy fixture missing")
  ref <- readRDS(f)
  now <- vapply(names(ref$versions), function(p) as.character(utils::packageVersion(p)), character(1))
  skip_if(!identical(unname(now), unname(ref$versions)), "dependency versions differ from the legacy fixture")
  ref
}

test_that("default mode reproduces the pre-change package bit-for-bit, RNG stream included", {
  skip_on_cran()
  ref <- legacy()
  obs <- sim_draw(42L); des <- sim_design(obs)
  tf <- tiny_frame(H = 3L, J = 6L, n0 = 15L, seed = 5L); tf$dom <- tf$x2 > -1
  tdes <- survey::svydesign(ids = ~cluster, strata = ~strata, weights = ~weight, data = tf)
  runs <- list(
    sim_glm_all = function(nw) svytmle(des, "Y", "A", c("L1", "L2", "L3", "L4"), learners = "SL.glm", arms = "all", nuisance_weights = nw),
    sim_2lrn_all = function(nw) svytmle(des, "Y", "A", c("L1", "L2", "L3", "L4"), learners = c("SL.glm", "SL.glmnet"), arms = "all", nuisance_weights = nw),
    tiny_dom_2lrn_all = function(nw) svytmle(tdes, "Y", "A", c("x1", "x2", "f1"), learners = c("SL.glm", "SL.glmnet"),
                                             subset = ~dom, arms = "all", cf_folds = 3L, nuisance_weights = nw),
    sim_aipw_glm = function(nw) svyaipw(des, "Y", "A", c("L1", "L2", "L3", "L4"), learners = "SL.glm", nuisance_weights = nw),
    tiny_dom_aipw_2lrn = function(nw) svyaipw(tdes, "Y", "A", c("x1", "x2", "f1"), learners = c("SL.glm", "SL.glmnet"),
                                              subset = ~dom, cf_folds = 3L, nuisance_weights = nw),
    sim_gaussian_cf = function(nw) svytmle(des, "Y", "A", c("L1", "L2", "L3", "L4"), learners = "SL.glm", arms = "cf",
                                           family = "gaussian", nuisance_weights = nw),
    sim_replicate_cf_fa = function(nw) svytmle(des, "Y", "A", c("L1", "L2", "L3", "L4"), learners = "SL.glm", arms = c("fa", "cf"),
                                               variance = "replicate", nuisance_weights = nw))
  seeds <- c(sim_glm_all = 1L, sim_2lrn_all = 2L, tiny_dom_2lrn_all = 3L, sim_aipw_glm = 4L, tiny_dom_aipw_2lrn = 5L,
             sim_gaussian_cf = 7L, sim_replicate_cf_fa = 8L)
  for (nm in names(runs)) for (mode in c("unweighted", "omitted")) {
    set.seed(seeds[[nm]])
    f <- suppressWarnings(if (mode == "omitted") runs[[nm]](formals(svytmle)$nuisance_weights[[2]]) else runs[[nm]](mode))
    expect_identical(f$results, ref$cases[[nm]]$results, label = paste(nm, mode, "results"))
    expect_identical(f$diagnostics, ref$cases[[nm]]$diagnostics, label = paste(nm, mode, "diagnostics"))
    expect_identical(.Random.seed, ref$cases[[nm]]$rng, label = paste(nm, mode, "RNG stream"))
  }
  # truly omitted argument, and two fits in sequence from one seed
  set.seed(6L)
  f1 <- suppressWarnings(svytmle(des, "Y", "A", c("L1", "L2", "L3", "L4"), learners = "SL.glm", arms = "cf"))
  f2 <- suppressWarnings(svytmle(tdes, "Y", "A", c("x1", "x2", "f1"), learners = "SL.glm", arms = "cf", cf_folds = 3L))
  expect_identical(rbind(f1$results, f2$results), ref$cases$chained$results)
  expect_identical(.Random.seed, ref$cases$chained$rng)
  expect_identical(f1$nuisance_weights, "unweighted")
  set.seed(9L)
  mi <- suppressWarnings(svytmle_mi(list(tiny_design(tiny_frame(seed = 21L)), tiny_design(tiny_frame(seed = 22L))),
                                    "Y", "A", c("x1", "x2"), learners = "SL.glm"))
  expect_identical(mi$results, ref$cases$mi_ambient$results)
  expect_identical(.Random.seed, ref$cases$mi_ambient$rng)
})

test_that(".cf_train_weights applies m_h / m_train,h per stratum and normalises to mean 1", {
  strata  <- c(1, 1, 1, 1, 2, 2)
  cluster <- c("a", "a", "b", "c", "d", "e")
  fold    <- c(1, 1, 2, 2, 1, 2)            # fold 1 holds out PSUs a (stratum 1) and d (stratum 2)
  w       <- c(2, 2, 4, 6, 1, 3)
  # training rows: b (w 4, stratum 1: 3 PSUs, 2 in training -> x1.5), c (w 6 -> x1.5),
  # e (w 3, stratum 2: 2 PSUs, 1 in training -> x2): (6, 9, 6) / mean 7
  expect_equal(.cf_train_weights(w, strata, cluster, fold, 1), c(6, 9, 6) / 7)
  expect_equal(mean(.cf_train_weights(w, strata, cluster, fold, 2)), 1)
  # PSU ids repeating across strata are keyed on the (stratum, PSU) pair
  expect_equal(.cf_train_weights(c(1, 1, 1, 1), c(1, 1, 2, 2), c("p", "q", "p", "q"), c(1, 2, 1, 2), 1), c(1, 1))
})

test_that("equal weights with balanced folds: survey mode equals unweighted mode exactly", {
  skip_on_cran()
  tf <- tiny_frame(H = 3L, J = 4L, n0 = 10L, seed = 9L); tf$weight <- 7
  des <- survey::svydesign(ids = ~cluster, strata = ~strata, weights = ~weight, data = tf)
  one <- function(nw, fun) { set.seed(3L); suppressWarnings(fun(nw)) }
  cf <- function(nw) svytmle(des, "Y", "A", c("x1", "x2", "f1"), learners = "SL.glm", arms = "cf", cf_folds = 2L, nuisance_weights = nw)
  ai <- function(nw) svyaipw(des, "Y", "A", c("x1", "x2", "f1"), learners = "SL.glm", arms = "cf", cf_folds = 2L, nuisance_weights = nw)
  expect_identical(one("survey", cf)$results, one("unweighted", cf)$results)
  expect_identical(one("survey", ai)$results, one("unweighted", ai)$results)
})

test_that("survey mode actually uses varying weights (estimates change; mode recorded and printed)", {
  skip_on_cran()
  tf <- tiny_frame(H = 3L, J = 6L, n0 = 15L, seed = 5L)
  des <- survey::svydesign(ids = ~cluster, strata = ~strata, weights = ~weight, data = tf)
  set.seed(8L); u <- suppressWarnings(svyaipw(des, "Y", "A", c("x1", "x2"), learners = "SL.glm", arms = "cf", cf_folds = 3L))
  set.seed(8L); s <- suppressWarnings(svyaipw(des, "Y", "A", c("x1", "x2"), learners = "SL.glm", arms = "cf", cf_folds = 3L,
                                              nuisance_weights = "survey"))
  expect_false(identical(u$results$b, s$results$b))
  expect_identical(s$nuisance_weights, "survey")
  expect_match(paste(utils::capture.output(print(s)), collapse = "\n"), "survey-weighted")
  expect_error(svytmle(des, "Y", "A", "x1", learners = "SL.glm", nuisance_weights = "bogus"))
})

test_that("informative stage-2 sampling: survey-weighted nuisances remove the bias", {
  skip_on_cran()
  # Finite population: 2 strata x 200 facilities; half small (N = 3), half large (N = 60).
  # A and Y both depend on facility size, which is NOT in C. Stage 1 SRS-WOR 100 of 200 per
  # stratum; stage 2 takes 3 per facility, so large facilities are under-represented
  # unless weighted. (With only ~20 PSUs per stratum the cross-fitted estimator carries a
  # visible finite-PSU product-of-errors bias in EITHER mode -- measured 2026-09-24:
  # survey-mode bias -0.029 at 20 PSUs/stratum vs +0.005 at 100 -- so the test uses 100.)
  set.seed(101)
  fac <- data.frame(stratum = rep(1:2, each = 200), fid = 1:400, big = rep(rep(0:1, each = 100), 2))
  fac$N <- ifelse(fac$big == 1, 60L, 3L)
  pop <- do.call(rbind, lapply(seq_len(nrow(fac)), function(i) {
    n <- fac$N[i]; b <- fac$big[i]
    A <- rbinom(n, 1, if (b == 1) 0.8 else 0.2)
    data.frame(stratum = fac$stratum[i], fid = fac$fid[i], N = n, x = rbinom(n, 1, 0.5), x2 = rnorm(n), A = A,
               Y = rbinom(n, 1, if (b == 1) 0.6 + 0.1 * A else 0.2 + 0.3 * A))
  }))
  truth <- mean(pop$Y[pop$A == 1]) - mean(pop$Y[pop$A == 0])   # population contrast (x, x2 are noise)
  draw <- function() {
    pick <- unlist(lapply(split(fac$fid, fac$stratum), function(k) sample(k, 100)))
    s <- do.call(rbind, lapply(pick, function(k) { d <- pop[pop$fid == k, ]; d[sample.int(nrow(d), min(3, nrow(d))), ] }))
    s$w <- (200 / 100) * (s$N / pmin(3, s$N))
    survey::svydesign(ids = ~fid, strata = ~stratum, weights = ~w, data = s)
  }
  est <- t(vapply(1:15, function(r) {
    set.seed(1000 + r); des <- draw()
    b <- function(nw) { set.seed(r); suppressWarnings(svyaipw(des, "Y", "A", c("x", "x2"), learners = "SL.glm", arms = "cf",
                                                              cf_folds = 5L, nuisance_weights = nw))$results$b }
    c(unweighted = b("unweighted"), survey = b("survey"))
  }, numeric(2)))
  bias <- colMeans(est) - truth
  expect_gt(abs(bias[["unweighted"]]), 0.10)                         # the default is visibly biased here (~0.18)
  expect_lt(abs(bias[["survey"]]), 0.04)                             # survey mode is not (~0.005; MC SE ~0.013)
  expect_lt(abs(bias[["survey"]]), abs(bias[["unweighted"]]) / 4)
})

test_that("svytmle_mi forwards nuisance_weights to every imputation", {
  skip_on_cran()
  designs <- lapply(1:2, function(k) tiny_design(tiny_frame(seed = 20L + k)))
  fit <- suppressWarnings(svytmle_mi(designs, "Y", "A", c("x1", "x2"), learners = "SL.glm", seed = 1L,
                                     nuisance_weights = "survey"))
  expect_identical(fit$nuisance_weights, "survey")
  manual <- vapply(1:2, function(k) { set.seed(1L + 1000L * k)
    suppressWarnings(svytmle(designs[[k]], "Y", "A", c("x1", "x2"), learners = "SL.glm", nuisance_weights = "survey"))$results$b },
    numeric(1))
  expect_identical(fit$per_imputation$b[fit$per_imputation$method == "Fully-Aware-CF"], manual)
  expect_match(paste(utils::capture.output(print(fit)), collapse = "\n"), "survey-weighted")
})

test_that("survey mode refuses learners that ignore obsWeights; SL.earth.w honours them", {
  skip_on_cran(); skip_if_not_installed("earth")
  tf <- tiny_frame(H = 3L, J = 6L, n0 = 15L, seed = 5L)
  des <- survey::svydesign(ids = ~cluster, strata = ~strata, weights = ~weight, data = tf)
  expect_error(svytmle(des, "Y", "A", c("x1", "x2"), learners = c("SL.glm", "SL.earth"), nuisance_weights = "survey"),
               "SL.earth.w")
  expect_error(svyaipw(des, "Y", "A", c("x1", "x2"), learners = "SL.earth", nuisance_weights = "survey"), "obsWeights")
  expect_error(svytmle_mi(list(des, des), "Y", "A", c("x1", "x2"), learners = "SL.earth", nuisance_weights = "survey"),
               "obsWeights")
  expect_warning(.check_nuisance_learners(c("SL.glm", "SL.mylearner"), "survey"), "cannot confirm")
  # the default mode is untouched by the guard
  expect_silent(.check_nuisance_learners("SL.earth", "unweighted"))
  # every member of the SPA survey-mode library changes its fit when weights are informative
  set.seed(4)
  n <- 400; X <- data.frame(x1 = rnorm(n), x2 = rnorm(n)); z <- rbinom(n, 1, 0.5)
  Y <- rbinom(n, 1, plogis(-1 + 2 * z + X$x1)); w <- ifelse(z == 1, 20, 1)
  for (L in c("SL.glm", "SL.earth.w", "SL.glmnet", "SL.ranger")) {
    if (L == "SL.ranger") skip_if_not_installed("ranger")
    set.seed(1); pu <- .sl(Y, X, weights = NULL, L)(X)
    set.seed(1); pw <- .sl(Y, X, weights = w / mean(w), L)(X)
    expect_gt(abs(mean(pw) - mean(pu)), 0.02, label = paste(L, "responds to weights"))
  }
  # with equal weights SL.earth.w fits the same model as SL.earth
  set.seed(1); pe <- .sl(Y, X, weights = NULL, "SL.earth")(X)
  set.seed(1); pw1 <- .sl(Y, X, weights = rep(1, n), "SL.earth.w")(X)
  expect_equal(pw1, pe, tolerance = 1e-8)
})

test_that("variance_methods() bootstrap refits in the fitted object's nuisance mode", {
  skip_on_cran()
  tf <- tiny_frame(H = 3L, J = 6L, n0 = 15L, seed = 5L)
  des <- survey::svydesign(ids = ~cluster, strata = ~strata, weights = ~weight, data = tf)
  set.seed(2); fit <- suppressWarnings(svytmle(des, "Y", "A", c("x1", "x2"), learners = "SL.glm", nuisance_weights = "survey"))
  seen <- character(0)
  real <- svytmle
  testthat::local_mocked_bindings(svytmle = function(..., nuisance_weights = "unweighted") {
    seen <<- c(seen, nuisance_weights); real(..., nuisance_weights = nuisance_weights) })
  suppressWarnings(variance_methods(fit, design = des, methods = "bootstrap", B = 2))
  expect_true(length(seen) >= 1 && all(seen == "survey"))
})
