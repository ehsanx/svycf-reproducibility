# Generates ref_legacy_nuisance.rds: outputs AND the RNG state after each call, from the
# UNMODIFIED package at commit a1a4a30 (0.1.1), i.e. BEFORE nuisance_weights existed.
# test-nuisance-weights.R requires the default and explicit "unweighted" modes to
# reproduce every case bit-for-bit, including the RNG stream.
# Regenerate from a checkout of a1a4a30 (NOT from a later source tree):
#   git worktree add <dir> a1a4a30
#   SVYTMLE_LEGACY_OUT=<this repo>/tests/testthat/fixtures/ref_legacy_nuisance.rds \
#     Rscript -e 'devtools::load_all("<dir>"); source("<dir>/tests/testthat/helper-sim.R");
#                 source("<this repo>/tests/testthat/fixtures/make_legacy_nuisance_fixture.R")'
out <- Sys.getenv("SVYTMLE_LEGACY_OUT", file.path("tests", "testthat", "fixtures", "ref_legacy_nuisance.rds"))
cases <- list()
obs <- sim_draw(42L); des <- sim_design(obs)
tf <- tiny_frame(H = 3L, J = 6L, n0 = 15L, seed = 5L); tf$dom <- tf$x2 > -1
tdes <- survey::svydesign(ids = ~cluster, strata = ~strata, weights = ~weight, data = tf)
run <- function(label, seed, expr) { set.seed(seed); f <- suppressWarnings(expr)
  cases[[label]] <<- list(results = f$results, diagnostics = f$diagnostics, rng = .Random.seed) }
run("sim_glm_all", 1L, svytmle(des, "Y", "A", c("L1", "L2", "L3", "L4"), learners = "SL.glm", arms = "all"))
run("sim_2lrn_all", 2L, svytmle(des, "Y", "A", c("L1", "L2", "L3", "L4"), learners = c("SL.glm", "SL.glmnet"), arms = "all"))
run("tiny_dom_2lrn_all", 3L, svytmle(tdes, "Y", "A", c("x1", "x2", "f1"), learners = c("SL.glm", "SL.glmnet"),
                                     subset = ~dom, arms = "all", cf_folds = 3L))
run("sim_aipw_glm", 4L, svyaipw(des, "Y", "A", c("L1", "L2", "L3", "L4"), learners = "SL.glm"))
run("tiny_dom_aipw_2lrn", 5L, svyaipw(tdes, "Y", "A", c("x1", "x2", "f1"), learners = c("SL.glm", "SL.glmnet"),
                                      subset = ~dom, cf_folds = 3L))
run("sim_gaussian_cf", 7L, svytmle(des, "Y", "A", c("L1", "L2", "L3", "L4"), learners = "SL.glm", arms = "cf", family = "gaussian"))
run("sim_replicate_cf_fa", 8L, svytmle(des, "Y", "A", c("L1", "L2", "L3", "L4"), learners = "SL.glm", arms = c("fa", "cf"),
                                       variance = "replicate"))
# two fits in sequence from one seed: catches any change in RNG consumption
set.seed(6L)
f1 <- suppressWarnings(svytmle(des, "Y", "A", c("L1", "L2", "L3", "L4"), learners = "SL.glm", arms = "cf"))
f2 <- suppressWarnings(svytmle(tdes, "Y", "A", c("x1", "x2", "f1"), learners = "SL.glm", arms = "cf", cf_folds = 3L))
cases$chained <- list(results = rbind(f1$results, f2$results), diagnostics = NULL, rng = .Random.seed)
set.seed(9L)
mi <- suppressWarnings(svytmle_mi(list(tiny_design(tiny_frame(seed = 21L)), tiny_design(tiny_frame(seed = 22L))),
                                  "Y", "A", c("x1", "x2"), learners = "SL.glm"))
cases$mi_ambient <- list(results = mi$results, diagnostics = NULL, rng = .Random.seed)
saveRDS(list(cases = cases, generated_from = "svytmle 0.1.1 at commit a1a4a30 (pre nuisance_weights)",
             versions = sapply(c("tmle", "SuperLearner", "survey", "glmnet"), function(p) as.character(packageVersion(p))),
             R = R.version.string), out)
cat("legacy fixture written:", length(cases), "cases ->", out, "\n")
