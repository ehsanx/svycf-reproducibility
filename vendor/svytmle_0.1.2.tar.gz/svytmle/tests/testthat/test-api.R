# input validation and wrapper behaviour (fast: SL.glm, cf arm only)

test_that("design-class and scope checks reject out-of-scope designs", {
  dat <- tiny_frame()
  des <- tiny_design(dat)
  # subset()-ed design rejected with guidance
  expect_error(svytmle(subset(des, x1 > 0), "Y", "A", c("x1", "x2"),
                       learners = "SL.glm"),
               "FULL design")
  # replicate-weight design: rejected by the default linearization path
  # (the internal guard), but ACCEPTED by svytmle() (it forces variance =
  # "replicate"); see test-extensions.R for the accepted path.
  rep_des <- survey::as.svrepdesign(des, type = "JKn")
  expect_error(svytmle:::.check_design(rep_des), "replicate")
  expect_silent(svytmle:::.check_design(rep_des, allow_replicate = TRUE))
  # non-design object rejected
  expect_error(svytmle(dat, "Y", "A", c("x1", "x2"), learners = "SL.glm"),
               "survey design")
  # FPC warning
  dat$fpc <- 12L
  des_fpc <- survey::svydesign(ids = ~cluster, strata = ~strata,
                               weights = ~weight, fpc = ~fpc, data = dat)
  expect_warning(.ignore <- svytmle:::.check_design(des_fpc), "FPC")
})

test_that("missing columns, NA covariates, and non-binary variables error clearly", {
  des <- tiny_design()
  expect_error(svytmle(des, "nope", "A", c("x1", "x2"), learners = "SL.glm"),
               "not found")
  expect_error(svytmle(des, "Y", "A", c("x1", "zz"), learners = "SL.glm"),
               "not found")
  dat <- tiny_frame(); dat$x1[3] <- NA
  expect_error(svytmle(tiny_design(dat), "Y", "A", c("x1", "x2"),
                       learners = "SL.glm"),
               "missing")
  dat2 <- tiny_frame(); dat2$Y <- dat2$Y + 1
  expect_error(svytmle(tiny_design(dat2), "Y", "A", c("x1", "x2"),
                       learners = "SL.glm"),
               "0/1")
})

test_that("subset must be a valid domain spec", {
  des <- tiny_design()
  expect_error(svytmle(des, "Y", "A", c("x1", "x2"), subset = c(TRUE, FALSE),
                       learners = "SL.glm"),
               "logical vector")
  expect_error(svytmle(des, "Y", "A", c("x1", "x2"), subset = ~ x1 > 99,
                       learners = "SL.glm"),
               "no rows")
  dat <- tiny_frame(); dat$bad <- NA
  expect_error(svytmle(tiny_design(dat), "Y", "A", c("x1", "x2"),
                       subset = ~ bad, learners = "SL.glm"),
               "NA")
})

test_that("the primary cf arm runs end to end with factors, domains, and methods", {
  dat <- tiny_frame()
  des <- tiny_design(dat)
  set.seed(2)
  fit <- svytmle(des, "Y", "A", c("x1", "x2", "f1"), learners = "SL.glm",
                 subset = ~ x2 < 1.5)
  expect_s3_class(fit, "svytmle")
  rr <- fit$results
  expect_identical(rr$method, "Fully-Aware-CF")
  expect_true(is.finite(rr$b) && rr$se > 0)
  # design df: all PSUs intersect the domain here
  expect_identical(rr$df, fit$n_psu - fit$n_strata)
  # t-reference CI
  expect_equal(rr$ucl - rr$b, qt(0.975, rr$df) * rr$se, tolerance = 1e-12)
  # one-hot encoding: factor f1 contributes nlevels-1 columns
  expect_true(all(c("f1b", "f1c") %in% fit$covariate_columns))
  # methods
  expect_named(coef(fit), "Fully-Aware-CF")
  expect_identical(dim(confint(fit)), c(1L, 2L))
  expect_output(print(fit), "Primary \\(cross-fitted\\) estimate")
  expect_output(print(summary(fit)), "truncation")
})

test_that("two-level factor treatment is converted with a message", {
  dat <- tiny_frame()
  dat$Af <- factor(ifelse(dat$A == 1, "treated", "control"),
                   levels = c("control", "treated"))
  set.seed(4)
  expect_message(
    fit <- svytmle(tiny_design(dat), "Y", "Af", c("x1", "x2"),
                   learners = "SL.glm"),
    "treated")
  set.seed(4)
  ref <- svytmle(tiny_design(dat), "Y", "A", c("x1", "x2"), learners = "SL.glm")
  expect_equal(fit$results$b, ref$results$b, tolerance = 1e-12)
})

test_that("fallback extraction warns but reproduces the same estimate", {
  dat <- tiny_frame()
  des <- tiny_design(dat)
  des2 <- des
  des2$call <- quote(unrecoverable())
  set.seed(9)
  fit1 <- svytmle(des, "Y", "A", c("x1", "x2"), learners = "SL.glm")
  set.seed(9)
  expect_warning(
    fit2 <- svytmle(des2, "Y", "A", c("x1", "x2"), learners = "SL.glm"),
    "falling back")
  # globally-unique integer PSU ids: same folds/partition; weights(design)
  # re-inversion can differ at the ulp level, so equal-to-1e-12, not bitwise
  expect_equal(fit1$results$b, fit2$results$b, tolerance = 1e-12)
  expect_equal(fit1$results$se, fit2$results$se, tolerance = 1e-12)
})

test_that("primary defaults are exactly the primary recipe", {
  f <- formals(svytmle)
  expect_identical(eval(f$learners), c("SL.glm", "SL.earth", "SL.glmnet"))
  expect_identical(f$arms, "cf")
  expect_identical(f$g_bound, 0.05)
  expect_identical(eval(f$cf_folds), 5L)
  expect_identical(eval(f$inner_cv_folds), 5L)
  expect_identical(f$level, 0.95)
  fe <- formals(svytmle:::run_estimators)
  expect_identical(fe$g_oof_bound, 0.05)
  expect_identical(eval(fe$arms), c("fa", "pa", "na", "cv", "cf"))
})
