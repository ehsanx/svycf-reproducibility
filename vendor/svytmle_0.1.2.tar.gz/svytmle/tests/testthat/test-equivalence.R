# equivalence with the reference implementation
# (survey-tmle2/codes/estimators.R), via fixtures frozen by
# inst/equivalence/make_fixtures.R. ANY mismatch here is a MUST-FIX in the
# package — never widen a tolerance (the reference numbers are the spec).
#
# The full bitwise gates live in inst/equivalence/ (equiv_sim.R needs the
# survey-tmle2 repo; equiv_nhanes.R reproduces the locked NHANES preview).

ref_fixture <- function(name) {
  f <- testthat::test_path("fixtures", name)
  skip_if_not(file.exists(f), paste("fixture", name, "missing"))
  readRDS(f)
}

test_that("package reproduces the reference (SL.glm, all arms)", {
  skip_on_cran()   # value comparison is pinned to the as-run package versions
  ref <- ref_fixture("ref_sim_glm.rds")
  obs <- sim_draw(42L)
  des <- sim_design(obs)
  set.seed(ref$seed)
  fit <- svytmle(des, outcome = "Y", treatment = "A",
                 covariates = c("L1", "L2", "L3", "L4"),
                 learners = ref$learners, arms = "all")
  expect_identical(fit$results$method, ref$results$method)
  same_versions <- identical(
    unname(ref$versions$pkgs[c("tmle", "SuperLearner", "survey")]),
    vapply(c("tmle", "SuperLearner", "survey"),
           function(p) as.character(utils::packageVersion(p)), character(1),
           USE.NAMES = FALSE))
  tol <- if (same_versions) 1e-12 else testthat_tolerance()
  expect_equal(fit$results$b,  ref$results$b,  tolerance = tol)
  expect_equal(fit$results$se, ref$results$se, tolerance = tol)
  expect_identical(fit$results$df, ref$results$df)
  expect_equal(as.list(fit$diagnostics), as.list(ref$drow), tolerance = tol)
})

test_that("package reproduces the reference (default 3-learner library)", {
  skip_on_cran()
  skip_if(Sys.getenv("SVYTMLE_EXTENDED") != "1",
          "set SVYTMLE_EXTENDED=1 for the full-library equivalence test (~4 min)")
  skip_if_not_installed("earth"); skip_if_not_installed("glmnet")
  ref <- ref_fixture("ref_sim_full.rds")
  obs <- sim_draw(42L)
  des <- sim_design(obs)
  set.seed(ref$seed)
  fit <- svytmle(des, outcome = "Y", treatment = "A",
                 covariates = c("L1", "L2", "L3", "L4"),
                 learners = ref$learners, arms = "all")
  expect_identical(fit$results$method, ref$results$method)  # includes the CV arm
  expect_equal(fit$results$b,  ref$results$b,  tolerance = 1e-12)
  expect_equal(fit$results$se, ref$results$se, tolerance = 1e-12)
  expect_identical(fit$results$df, ref$results$df)
})

test_that("NHANES locked-preview equivalence (developer gate)", {
  skip_on_cran()
  nh <- Sys.getenv("SVYTMLE_NHANES_DIR")
  skip_if(nh == "", "set SVYTMLE_NHANES_DIR=<survey-tmle2 path> (and ~25 min) for the E3 NHANES gate")
  skip_if_not_installed("earth"); skip_if_not_installed("glmnet")
  obs <- readRDS(file.path(nh, "Nhanes", "analytic", "E3_imputed.rds"))
  locked <- utils::read.csv(file.path(nh, "Nhanes", "results",
                                      "local_preview_summary.csv"))
  lk <- locked[locked$example == "E3", ]
  des <- survey::svydesign(ids = ~SDMVPSU, strata = ~SDMVSTRA,
                           weights = ~WTMEC_POOLED, data = obs, nest = TRUE)
  set.seed(20260607L)
  fit <- svytmle(des, outcome = "Y", treatment = "A",
                 covariates = attr(obs, "covs"),
                 learners = c("SL.glm", "SL.earth", "SL.glmnet"),
                 subset = ~inpop, arms = "all")
  # gate arms only: the locked CSV's Fully-Aware-CV row predates the primary
  # engine's CV-arm refinement and is NOT a target (see inst/equivalence/README.md)
  lk <- lk[lk$method %in% c("Fully-Aware", "Partially-Aware", "Non-Aware",
                            "Fully-Aware-CF"), ]
  m <- match(lk$method, fit$results$method)
  for (col in c("b", "se", "lcl", "ucl"))
    expect_equal(round(fit$results[[col]][m], 4), lk[[col]],
                 tolerance = 1e-12, label = paste("E3", col, "(4 dp)"))
  expect_identical(fit$results$df[m], lk$df)
})
