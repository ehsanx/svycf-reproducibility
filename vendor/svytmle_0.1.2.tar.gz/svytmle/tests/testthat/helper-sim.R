# shared test helpers: small deterministic simulated designs

# the gate-(b)/fixture draw: the paper's standard/simple scenario
sim_draw <- function(sample_seed = 42L) {
  pop <- make_population("standard", "simple", truth_M = 1e4L)
  draw_sample(pop, sample_seed = sample_seed)
}

sim_design <- function(obs) {
  survey::svydesign(ids = ~cluster, strata = ~strata, weights = ~weight,
                    data = obs)
}

# a tiny artificial stratified-cluster frame for fast structural tests:
# H strata x J PSUs x n0 members, binary A/Y, two covariates + one factor
tiny_frame <- function(H = 4L, J = 3L, n0 = 12L, seed = 11L) {
  set.seed(seed)
  n <- H * J * n0
  strata  <- rep(seq_len(H), each = J * n0)
  cluster <- rep(seq_len(H * J), each = n0)          # globally unique PSU ids
  x1 <- rnorm(n); x2 <- rnorm(n)
  f1 <- factor(sample(c("a", "b", "c"), n, replace = TRUE))
  A  <- rbinom(n, 1, plogis(0.4 * x1))
  Y  <- rbinom(n, 1, plogis(-0.5 + 0.7 * A + 0.5 * x1 - 0.3 * x2))
  weight <- rep(rep(c(1.5, 2.5, 4), length.out = J)[seq_len(J)], each = n0,
                times = H) * 10
  data.frame(strata, cluster, weight, x1, x2, f1, A, Y)
}

tiny_design <- function(dat = tiny_frame()) {
  survey::svydesign(ids = ~cluster, strata = ~strata, weights = ~weight,
                    data = dat)
}
