# P1 additions: family="gaussian", riskratio()/oddsratio(), svytmle_mi(),
# svyaipw(), and the confint(level=)/as.data.frame()/overlap() helpers.
# Fast: SL.glm only.

test_that("family = 'gaussian' runs and reports a mean difference", {
  dat <- tiny_frame()
  dat$Yc <- plogis(0.4 * dat$x1 + 0.6 * dat$A - 0.2 * dat$x2)  # bounded continuous
  des <- tiny_design(dat)
  set.seed(3)
  fit <- svytmle(des, "Yc", "A", c("x1", "x2"), learners = "SL.glm",
                 family = "gaussian", arms = c("fa", "cf"))
  expect_identical(fit$family, "gaussian")
  expect_true(is.finite(fit$results$b[fit$results$method == "Fully-Aware-CF"]))
  expect_output(print(fit), "mean difference")
  # gaussian outcomes need not be 0/1
  expect_silent(svytmle:::.num_outcome(dat$Yc, "Yc", seq_len(nrow(dat))))
})

test_that("riskratio()/oddsratio() post-process a fit consistently", {
  dat <- tiny_frame()
  des <- tiny_design(dat)
  set.seed(5)
  fit <- svytmle(des, "Y", "A", c("x1", "x2"), learners = "SL.glm", arms = c("fa", "cf"))
  rr <- riskratio(fit); orr <- oddsratio(fit)
  expect_identical(rr$estimand, "RR")
  expect_identical(orr$estimand, "OR")
  # point estimates equal the ratios of the stored per-arm means
  expect_equal(rr$est,  rr$psi1 / rr$psi0, tolerance = 1e-6)
  expect_equal(orr$est, (orr$psi1 / (1 - orr$psi1)) / (orr$psi0 / (1 - orr$psi0)),
               tolerance = 1e-6)
  expect_true(rr$lo < rr$est && rr$est < rr$hi)
  expect_identical(attr(rr, "arm"), "Fully-Aware-CF")
  expect_identical(attr(riskratio(fit, arm = "fa"), "arm"), "Fully-Aware")
  # an arm not run -> informative error (default cf fit lacks the fa components)
  set.seed(5)
  fit_cf <- svytmle(des, "Y", "A", c("x1", "x2"), learners = "SL.glm")
  expect_error(riskratio(fit_cf, arm = "fa"), "not in this fit")
})

test_that("oddsratio() is rejected for a gaussian outcome", {
  dat <- tiny_frame()
  dat$Yc <- plogis(0.4 * dat$x1 + 0.6 * dat$A)
  set.seed(7)
  fit <- svytmle(tiny_design(dat), "Yc", "A", c("x1", "x2"), learners = "SL.glm",
                 family = "gaussian", arms = "cf")
  expect_error(oddsratio(fit), "binary outcome")
  expect_identical(riskratio(fit)$estimand, "RR")   # ratio of means
})

test_that("svytmle_mi() pools by Rubin's rules with Barnard-Rubin df", {
  designs <- lapply(1:3, function(k) tiny_design(tiny_frame(seed = 10L + k)))
  mi <- svytmle_mi(designs, "Y", "A", c("x1", "x2"), learners = "SL.glm", seed = 1L)
  expect_s3_class(mi, "svytmle_mi")
  expect_identical(mi$M, 3L)
  rr <- mi$results
  expect_identical(rr$method, "Fully-Aware-CF")
  expect_true(is.finite(rr$b) && rr$se > 0)
  # pooled point estimate is the mean of the per-imputation estimates
  expect_equal(rr$b, mean(mi$per_imputation$b), tolerance = 1e-12)
  # Barnard-Rubin df never exceeds the complete-data design df
  df_complete <- mi$per_imputation$df[1]
  expect_lte(rr$df, df_complete + 1e-8)
  expect_true(rr$fmi >= 0 && rr$fmi <= 1)
  expect_output(print(mi), "MI-pooled")
  # input validation
  expect_error(svytmle_mi(designs[[1]], "Y", "A", c("x1", "x2")), "LIST")
  expect_error(svytmle_mi(designs[1], "Y", "A", c("x1", "x2")), "at least 2")
})

test_that("riskratio()/oddsratio() Rubin-pool across imputations", {
  designs <- lapply(1:3, function(k) tiny_design(tiny_frame(seed = 20L + k)))
  mi <- svytmle_mi(designs, "Y", "A", c("x1", "x2"), learners = "SL.glm", seed = 2L)
  rr <- riskratio(mi); orr <- oddsratio(mi)
  expect_identical(rr$estimand, "RR")
  expect_identical(orr$estimand, "OR")
  expect_true(is.finite(rr$est) && rr$lo < rr$est && rr$est < rr$hi)
  expect_true(rr$fmi >= 0 && rr$fmi <= 1 && rr$M == 3L)
  # pooled point = exp(mean of the per-imputation log-RRs) for the cf arm
  s <- mi$per_imputation_ratio
  s <- s[s$arm == "Fully-Aware-CF" & s$estimand == "RR", ]
  expect_equal(rr$est, exp(mean(s$log_est)), tolerance = 1e-10)
  # df never exceeds the complete-data design df
  expect_lte(rr$df, s$df[1] + 1e-8)
})

test_that("svyaipw() returns SF and CF arms with both variances", {
  dat <- tiny_frame()
  des <- tiny_design(dat)
  set.seed(8)
  ai <- svyaipw(des, "Y", "A", c("x1", "x2"), learners = "SL.glm")
  expect_s3_class(ai, "svyaipw")
  expect_setequal(ai$results$method, c("AIPW-SF", "AIPW-CF"))
  expect_true(all(ai$results$se_jkn > 0) && all(ai$results$se_lin > 0))
  expect_equal(ai$results$se, ai$results$se_lin, tolerance = 1e-12)  # CI basis
  # t-reference CI on the linearized SE
  i <- which(ai$results$method == "AIPW-CF")
  expect_equal(ai$results$ucl[i] - ai$results$b[i],
               qt(0.975, ai$results$df[i]) * ai$results$se[i], tolerance = 1e-12)
  expect_named(coef(ai), "AIPW-CF")           # cross-fit arm is primary
  expect_output(print(ai), "AIPW")
  # single arm
  set.seed(8)
  cf_only <- svyaipw(des, "Y", "A", c("x1", "x2"), learners = "SL.glm", arms = "cf")
  expect_identical(cf_only$results$method, "AIPW-CF")
  # continuous not yet supported
  expect_error(svyaipw(des, "Y", "A", c("x1", "x2"), family = "gaussian"), "binomial")
})

test_that("variance = 'replicate' keeps the point estimate, swaps the SE", {
  dat <- tiny_frame()
  des <- tiny_design(dat)
  set.seed(11)
  lin <- svytmle(des, "Y", "A", c("x1", "x2"), learners = "SL.glm")
  set.seed(11)
  rep <- svytmle(des, "Y", "A", c("x1", "x2"), learners = "SL.glm",
                 variance = "replicate")
  expect_identical(rep$variance, "replicate")
  expect_equal(rep$results$b, lin$results$b, tolerance = 1e-12)   # point est unchanged
  expect_true(is.finite(rep$results$se) && rep$results$se > 0)
  expect_output(print(rep), "replicate-weight variance")
  # foil arms are rejected under replicate variance
  expect_error(svytmle(des, "Y", "A", c("x1", "x2"), learners = "SL.glm",
                       arms = "all", variance = "replicate"), "replicate")
})

test_that("a svyrep.design is accepted and forces replicate variance", {
  dat <- tiny_frame()
  rep_des <- survey::as.svrepdesign(tiny_design(dat), type = "JKn")
  set.seed(12)
  fit <- svytmle(rep_des, "Y", "A", c("x1", "x2"), learners = "SL.glm")
  expect_identical(fit$variance, "replicate")
  expect_identical(fit$extraction, "svrep")
  expect_true(is.finite(fit$results$b) && fit$results$se > 0)
})

test_that("deff() and tidy()/glance() work", {
  dat <- tiny_frame()
  set.seed(13)
  fit <- svytmle(tiny_design(dat), "Y", "A", c("x1", "x2"), learners = "SL.glm",
                 arms = c("fa", "cf"))
  d <- deff(fit)
  expect_true(is.data.frame(d) && all(c("deff_clust", "icc_eif") %in% names(d)))
  expect_true(is.finite(d$deff_clust[1]) && d$deff_clust[1] > 0)
  td <- generics::tidy(fit)
  expect_true(all(c("term", "estimate", "std.error", "conf.low", "conf.high") %in% names(td)))
  expect_identical(nrow(td), nrow(fit$results))
  gl <- generics::glance(fit)
  expect_identical(gl$estimator, "TMLE")
  expect_true("primary" %in% names(gl))
})

test_that("confint() re-levels without refit; as.data.frame()/overlap() work", {
  dat <- tiny_frame()
  des <- tiny_design(dat)
  set.seed(9)
  fit <- svytmle(des, "Y", "A", c("x1", "x2"), learners = "SL.glm", arms = c("fa", "cf"))
  ci95 <- confint(fit); ci90 <- confint(fit, level = 0.90)
  expect_equal(ci95["Fully-Aware-CF", ], confint(fit, level = 0.95)["Fully-Aware-CF", ])
  expect_lt(diff(ci90["Fully-Aware-CF", ]), diff(ci95["Fully-Aware-CF", ]))
  expect_error(confint(fit, level = 1.5), "in \\(0, 1\\)")
  # arm-code selection
  expect_identical(rownames(confint(fit, parm = "cf")), "Fully-Aware-CF")
  # as.data.frame
  d <- as.data.frame(fit)
  expect_true(all(c("method", "estimate", "se", "conf.low", "conf.high") %in% names(d)))
  # overlap diagnostic
  ov <- overlap(fit)
  expect_true(is.data.frame(ov) && "pct_at_floor" %in% names(ov) && nrow(ov) >= 1)
})
