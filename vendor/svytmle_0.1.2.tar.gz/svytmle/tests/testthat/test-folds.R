# primary fold-construction properties (make_cf_folds)

test_that("folds are whole PSUs nested within strata", {
  dat <- tiny_frame()
  set.seed(3)
  fold <- svytmle:::make_cf_folds(dat$strata, dat$cluster, V = 3L)
  expect_identical(attr(fold, "unit"), "psu")
  # every (stratum, PSU) pair maps to exactly one fold
  key <- paste(dat$strata, dat$cluster)
  expect_true(all(tapply(fold, key, function(f) length(unique(f))) == 1L))
})

test_that("V is reduced to the minimum PSUs per stratum, never below 2", {
  dat <- tiny_frame(H = 4L, J = 3L)         # 3 PSUs per stratum
  set.seed(3)
  fold <- svytmle:::make_cf_folds(dat$strata, dat$cluster, V = 5L)
  expect_identical(attr(fold, "V_eff"), 3L) # min PSUs/stratum = 3 < V = 5
  dat2 <- tiny_frame(H = 5L, J = 2L)        # 2 PSUs per stratum
  set.seed(3)
  fold2 <- svytmle:::make_cf_folds(dat2$strata, dat2$cluster, V = 5L)
  expect_identical(attr(fold2, "V_eff"), 2L) # leave-one-PSU-per-stratum-out
})

test_that("a 3-PSU stratum splits 2-1 at V = 2 (balanced within-stratum allocation)", {
  dat <- tiny_frame(H = 6L, J = 3L)
  set.seed(7)
  fold <- svytmle:::make_cf_folds(dat$strata, dat$cluster, V = 2L)
  expect_identical(attr(fold, "V_eff"), 2L)
  first <- !duplicated(paste(dat$strata, dat$cluster))
  key <- data.frame(s = dat$strata[first], c = dat$cluster[first], f = fold[first])
  per <- table(key$s, key$f)
  expect_true(all(per %in% c(1L, 2L)))      # each stratum: 2-1, never 3-0
  expect_true(all(rowSums(per) == 3L))
})

test_that("folds are correct when PSU ids repeat across strata (NHANES-style)", {
  dat <- tiny_frame(H = 4L, J = 3L)
  dat$psu_rep <- ((dat$cluster - 1L) %% 3L) + 1L   # ids 1..3 repeat per stratum
  set.seed(5)
  fold <- svytmle:::make_cf_folds(dat$strata, dat$psu_rep, V = 3L)
  key <- paste(dat$strata, dat$psu_rep)
  expect_true(all(tapply(fold, key, function(f) length(unique(f))) == 1L))
  # 12 distinct (stratum, PSU) units, every fold non-empty
  expect_identical(length(unique(paste(dat$strata, dat$psu_rep, fold))), 12L)
  expect_true(all(1:3 %in% fold))
})
