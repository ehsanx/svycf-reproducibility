# svytmle 0.1.2

* **New opt-in `nuisance_weights = c("unweighted", "survey")`** for `svytmle()`,
  `svyaipw()` and `svytmle_mi()`.
  * **Default `"unweighted"` is unchanged.** It reproduces the previous release
    bit-for-bit, RNG stream included, on the nine fixture cases listed below,
    checked by `tests/testthat/test-nuisance-weights.R`.
  * **What `"survey"` does.** The cross-fitted arm's out-of-fold outcome and
    propensity fits (and the CV arm's full-sample fits) use the survey weights.
    Within each training fold they are rescaled by `m_h / m_train,h`, the
    stratum's PSU count over its PSUs in that fold, and normalised to mean 1.
    Use it when sampling may be informative given the covariates.
  * **What is unchanged.** Targeting, the influence-function reconstruction and
    the design variance are the same in both modes.
  * **Where the mode is recorded.** In the fitted object (`$nuisance_weights`),
    and in the printed header when `"survey"`.
* **Learners must honour the weights in survey mode.** SuperLearner passes
  weights to a learner only through `obsWeights`, and several stock wrappers
  ignore them, notably `SL.earth` from the default library. So
  `nuisance_weights = "survey"` now stops for known weight-ignoring wrappers,
  and warns for wrappers it cannot confirm.
  * **New exported `SL.earth.w`:** a weight-honouring drop-in for `SL.earth`.
    With equal weights it fits the same model.
  * **Default mode is untouched by this check.**
* **`variance_methods()` full-refit bootstrap** now refits in the fitted object's
  nuisance mode. Objects from before 0.1.2 refit as `"unweighted"`, as before.
* **Survey mode warns** when a domain leaves a stratum with no PSU in a
  cross-fit training fold.
* **The backward-compatibility fixture** (`ref_legacy_nuisance.rds`) was
  generated from a checkout of commit a1a4a30. It records results,
  diagnostics and the RNG state for nine cases:
  * all arms, the CV arm and the domain path;
  * both AIPW protocols;
  * `family = "gaussian"` and `variance = "replicate"`;
  * two sequential fits;
  * `svytmle_mi`.
* The pkgdown site under `docs/` has not been rebuilt for 0.1.2.
* **Known environment note.** In the development environment on 2026-09-24,
  `test-equivalence.R` ("SL.glm, all arms") no longer matches its 2026-06-11
  fixture, on the unmodified 0.1.1 source as well as the installed 0.1.1 build.
  tmle, SuperLearner, survey and R are at the recorded versions. The drift
  predates this release and is not caused by it.

# svytmle 0.1.1

* **Correctness fix — single-fit arms.** The Fully-Aware and Non-Aware single-fit
  arms now pass `cvQinit = FALSE` to `tmle()`. `tmle` >= 2.x defaults `cvQinit = TRUE`,
  which cross-validates the initial outcome model — so the "single-fit" arms were
  quietly cross-validating Q, understating their coverage collapse under aggressive
  learners. This aligns svytmle with the corrected paper engine.
* **EIF g-bounds.** `.eif_from_tmle()` now reconstructs the influence function with
  the fit's own g-bounds (`fit$g$bound`), replicating `tmle`'s internal bounding,
  instead of a fixed `1e-3` truncation. The primary cross-fitted (`arms = "cf"`) path
  is unaffected by either change.
* Refreshed the shipped NHANES five-arm preview
  (`inst/extdata/nhanes_five_arm_preview.csv`) to the corrected-engine values.

# svytmle 0.1.0.9000 (development)

Applied-coverage additions (target B + user-facing C-subset; the primary
`arms = "cf"` path stays bit-for-bit identical — verified by the equivalence
tests at tolerance 1e-12). See `packaging/svyplan.md` in the analysis repo.

* **`svytmle_mi()`** — multiple-imputation pooling of the primary estimator by
  Rubin's rules with the **Barnard-Rubin (1999) small-sample df** anchored on the
  survey design df (not `n - 1`). Takes a *list* of completed-data survey designs;
  reproduces the headline NHANES Table-2 path and matches `mice::pool()`.
* **`svyaipw()`** — a first-class survey-weighted AIPW *comparator* (single-fit +
  cross-fit), with the Equation-8 design SE (CI basis) and a survey JKn replicate
  SE (`se_jkn`). Byte-faithful port of the paper's AIPW benchmark. Not validated;
  the validated-equivalence claim stays scoped to `svytmle(arms = "cf")`.
* **`variance_methods()`** — variance-method benchmark (Web Table S35): compare
  the design-based linearization SE with the delete-one-PSU jackknife, BRR, Fay's
  BRR, and the Rao--Wu--Yue subbootstrap on the *same* fitted influence function,
  plus an optional full-refit cluster bootstrap (`B > 0`, needs the original
  design) that re-cross-fits every nuisance. Reports SE, SE-ratio, CI, and timing.
* **`benchmark_compute()`** — per-estimator compute benchmark (Web Table S36):
  time the wall-clock/CPU cost of the design-awareness arms, survey AIPW, the
  RR/OR delta post-processor, and a deployable Super Learner. Neither benchmark
  touches the estimation engine, so the equivalence claim is unaffected.
* **`riskratio()` / `oddsratio()`** — relative effects directly from a fit (wire
  `delta_rr_or()` over the stored per-arm components); `riskratio()` returns the
  ratio of means for a continuous outcome.
* **`family = "gaussian"`** is now reachable from `svytmle()` (and `svytmle_mi()`)
  for a bounded continuous outcome (mean difference) — an opt-in, **unvalidated**
  branch separate from the binary-RD primary path.
* **Replicate-weight variance** via `variance = "replicate"`: keeps the primary
  point estimate and per-unit influence function but takes the SE and t-df from a
  replicate-weight design (`as.svrepdesign(..., type = replicate_type)`, default
  JKn). A `survey::svrepdesign` is now accepted directly (forcing replicate
  variance with observation-level cross-fitting), unlocking BRFSS / NHIS-BRR /
  CCHS / ACS / DHS. Supports `arms` `"cf"`/`"fa"`; validated only on a
  linearization design.
* **Rubin-pooled relative effects under MI**: `riskratio()` / `oddsratio()` now
  have `svytmle_mi` methods that pool the per-imputation log-RR / log-OR (or
  log-ratio-of-means) across imputations on the log scale and exponentiate.
* **`tidy()` / `glance()`** (broom, via `generics`) and **`deff()`** (the
  clustering design effect + ICC of a fitted arm's influence function).
* **pkgdown site** (`_pkgdown.yml`, grouped reference) for GitHub Pages
  (`https://ehsanx.github.io/svytmle/`).
* **E4 example refreshed for the `RHD180` sentinel-recode fix** (the analysis
  repo's N1 fix, `777/999` not `7777/9999`): the shipped E4 preview row, the
  equivalence fixture, and the E4 vignette now carry the corrected numbers
  (primary CF 0.0057 -> 0.0141; MI CF -> 0.013). E1-E3 unchanged.
* **`confint(level = )`** now re-levels a fit without refitting (the design df is
  fixed); added **`as.data.frame()`** (named CI columns) and **`overlap()`**
  (propensity positivity / mass-at-floor diagnostic).
* `man/` regenerated (incl. `delta_rr_or.Rd`); `DESCRIPTION` `URL`/`BugReports`
  point at the package repo; `generics` added to Imports. `R CMD check` 0/0/0.
  _Remaining for CRAN: a real maintainer email._

# svytmle 0.1.0

* Initial package build around the primary five-arm survey-TMLE engine of
  Karim (2026, submitted): `svytmle()` takes a `survey::svydesign` plus an
  outcome/treatment/covariate specification and returns the population ATE
  with a design-based (Taylor linearization) SE and t-reference CI
  (df = #PSU - #strata).
* Defaults are the paper's primary cross-fitted estimator exactly:
  PSU-level cross-fitting with balanced (cyclic-size, randomized) fold
  allocation within strata,
  unweighted out-of-fold nuisance fits, [0.05, 0.95] truncation of the
  out-of-fold propensity, survey weights only at the targeting and variance
  steps, and the arm-specific two-parameter fluctuation (epsilon0, epsilon1)
  on (H0W, H1W) via the `tmle` engine with an unweighted EIF reconstruction.
* `arms = "all"` reproduces the paper's five-arm benchmark in the as-run
  order; equivalence with the reference implementation is verified by the
  tests in `tests/testthat/` and the scripts in `inst/equivalence/`.
* Ships the paper's simulation DGP (`make_population()`, `draw_sample()`).
* Tier-1 estimand feature: the engine now exposes the per-arm targeted means and
  influence functions (`diagnostics$arms`, additive and non-breaking -- the scalar
  ATE and its EIF are byte-identical), and the new exported `delta_rr_or()` turns
  them into design-based delta-method Wald intervals for the **risk ratio** and
  **odds ratio** (binary) or the **ratio of means** (continuous). `run_estimators()`
  gains a `family` argument (`"binomial"` default, `"gaussian"` for a bounded
  continuous outcome via the [0,1] device), threaded through every arm. Theory:
  the RR/OR + bounded-continuous corollary (paper Web Appendix A). _P5 TODO before
  CRAN: regenerate `man/` via `devtools::document()`, add `tidy()`/`broom`,
  `confint(level=)`, and the S3 wiring of `delta_rr_or()` into the `svytmle` object._
