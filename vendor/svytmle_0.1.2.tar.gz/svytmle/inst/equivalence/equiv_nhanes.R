# =====================================================================
# Equivalence gate (a): the four NHANES analyses —
#   svytmle::svytmle(arms = "all", seed 20260607, default library)
#   must reproduce the LOCKED five-arm preview
#   (survey-tmle2/Nhanes/results/local_preview_summary.csv) at quoted
#   precision (4 decimals) for the CERTIFIED Fully-Aware-CF row — the
#   gate criterion — and (bonus armor, invariant to engine history) for
#   the Fully-Aware / Partially-Aware / Non-Aware rows.
#
# THE CV COMPARISON ROW IS REPORT-ONLY, by design, with a documented
# reason: the locked preview was produced 2026-06-07 (pre-fix), and the
# reference engine's CV arm changed on 2026-06-08 (survey-tmle2 commit
# 86c9f81: on the real-data domain path the CV arm now fits its nuisances
# UNWEIGHTED, like the primary CF arm — the 'w_cv' line). The package
# implements the CURRENT reference engine (bitwise — see equiv_sim.R), so
# its CV values intentionally differ from the pre-fix locked CV rows by
# ~1e-3. The companion script equiv_nhanes_oldcv.R demonstrates that the
# PRE-fix engine (git c49e08f) reproduces the locked CV row exactly,
# closing the provenance loop. Treating the locked CV row as a target
# would validate the SUPERSEDED estimator — that is the one deliberate,
# documented exception to "any mismatch is a must-fix".
#
# Also reports full-precision deltas against the locked per-example RDS
# (Nhanes/results/<id>/estimators_all_arms.rds — the CSV's source) and
# SAVES the package's per-example results (svytmle_nhanes_<id>.rds) so
# future re-adjudication needs no re-run.
#
# Usage: Rscript inst/equivalence/equiv_nhanes.R [E1 E2 E3 E4]
#   (default: E3 E4 E2 E1 — smallest first, fail fast; ~1-3 h total)
# Writes equivalence_report_nhanes.md + a per-example progress CSV next to
# the package root; exits nonzero on failure.
# =====================================================================
REF <- Sys.getenv("SVYTMLE_REF", "../survey-tmle2")
PKG <- Sys.getenv("SVYTMLE_PKG", ".")
dir.create(file.path(PKG, "dev", "equivalence"), recursive = TRUE, showWarnings = FALSE)

if (!requireNamespace("svytmle", quietly = TRUE)) {
  pkgload::load_all(PKG, quiet = TRUE)
} else library(svytmle)

LIB  <- c("SL.glm", "SL.earth", "SL.glmnet")   # default library
SEED <- 20260607L                              # reference seed (set per example)
GATE_ARMS <- c("Fully-Aware", "Partially-Aware", "Non-Aware", "Fully-Aware-CF")

locked <- utils::read.csv(file.path(REF, "Nhanes", "results",
                                    "local_preview_summary.csv"),
                          stringsAsFactors = FALSE)
ids <- commandArgs(trailingOnly = TRUE)
if (!length(ids)) ids <- c("E3", "E4", "E2", "E1")

report  <- file.path(PKG, "dev", "equivalence", "equivalence_report_nhanes.md")
progcsv <- file.path(PKG, "dev", "equivalence", "equivalence_nhanes_progress.csv")
lines <- c("# svytmle equivalence report — gate (a): NHANES E1-E4 vs the locked preview",
           sprintf("date: %s | R %s | library %s | seed %d",
                   format(Sys.time()), getRversion(), paste(LIB, collapse = "+"), SEED),
           "",
           paste("Gate criterion: the primary Fully-Aware-CF row (plus the FA/PA/NA",
                 "single-fit rows) at the CSV's quoted 4-dp precision. The CV row is",
                 "REPORT-ONLY: the locked CSV predates the reference engine's CV-arm",
                 "fix (unweighted domain nuisances, survey-tmle2 commit 86c9f81,",
                 "2026-06-08), so the current engine — which this package matches",
                 "bitwise — intentionally gives slightly different CV values. See the",
                 "script header and equiv_nhanes_oldcv.R."), "")
fails <- 0L; prog <- NULL
note <- function(...) { msg <- sprintf(...); cat(msg, "\n"); lines <<- c(lines, msg) }

for (id in ids) {
  obs  <- readRDS(file.path(REF, "Nhanes", "analytic", paste0(id, "_imputed.rds")))
  covs <- attr(obs, "covs")
  des  <- survey::svydesign(ids = ~SDMVPSU, strata = ~SDMVSTRA,
                            weights = ~WTMEC_POOLED, data = obs, nest = TRUE)
  set.seed(SEED)
  t0 <- proc.time()[3]
  fit <- svytmle(des, outcome = "Y", treatment = "A", covariates = covs,
                 learners = LIB, subset = ~inpop, arms = "all")
  secs <- round(proc.time()[3] - t0)
  rr <- fit$results
  saveRDS(list(results = rr, diagnostics = fit$diagnostics, secs = secs,
               id = id, seed = SEED, learners = LIB,
               versions = vapply(c("tmle", "SuperLearner", "survey", "surveyCV",
                                   "earth", "glmnet"),
                                 function(p) as.character(utils::packageVersion(p)),
                                 character(1))),
          file.path(PKG, "dev", "equivalence", sprintf("equivalence_svytmle_nhanes_%s.rds", id)),
          version = 3)

  lk <- locked[locked$example == id, ]
  m  <- match(lk$method, rr$method)
  note("## %s (%s) — %d s, n_domain = %d, %d PSUs / %d strata",
       id, lk$label[1], secs, fit$n_domain, fit$n_psu, fit$n_strata)
  ex_fail <- 0L
  for (k in seq_len(nrow(lk))) {
    r <- rr[m[k], ]
    gated <- lk$method[k] %in% GATE_ARMS
    for (col in c("b", "se", "lcl", "ucl")) {
      ok <- abs(round(r[[col]], 4) - lk[[col]][k]) < 1e-12
      if (!ok && gated) {
        ex_fail <- ex_fail + 1L
        note("- **FAIL** %s / %s: package %.6f (rounds to %.4f) vs locked %.4f",
             lk$method[k], col, r[[col]], round(r[[col]], 4), lk[[col]][k])
      }
      if (!ok && !gated)
        note("- (report-only) %s / %s: package %.6f vs locked %.4f — expected, pre-fix legacy CV row",
             lk$method[k], col, r[[col]], lk[[col]][k])
    }
    if (r$df != lk$df[k]) {
      if (gated) {
        ex_fail <- ex_fail + 1L
        note("- **FAIL** %s / df: package %d vs locked %d", lk$method[k], r$df, lk$df[k])
      } else
        note("- (report-only) %s / df: package %d vs locked %d", lk$method[k], r$df, lk$df[k])
    }
  }
  # full-precision deltas vs the locked RDS (the CSV's source), per arm
  ref_rds <- file.path(REF, "Nhanes", "results", id, "estimators_all_arms.rds")
  if (file.exists(ref_rds)) {
    fr <- readRDS(ref_rds)$results
    for (k in seq_len(nrow(fr))) {
      j <- match(fr$method[k], rr$method)
      dmax <- max(abs(unlist(fr[k, c("b", "se", "lcl", "ucl")]) -
                      unlist(rr[j, c("b", "se", "lcl", "ucl")])))
      note("- full-precision max |delta| vs locked RDS, %s: %.3e%s",
           fr$method[k], dmax, if (dmax == 0) " (bitwise identical)" else "")
    }
  }
  note("- gate cells (FA/PA/NA/CF x b,se,lcl,ucl,df): %s",
       if (ex_fail == 0L) "ALL PASS" else sprintf("**%d FAIL**", ex_fail))
  note("")
  fails <- fails + ex_fail
  prog <- rbind(prog, data.frame(example = id, secs = secs, fails = ex_fail))
  utils::write.csv(prog, progcsv, row.names = FALSE)
  writeLines(lines, report)   # incremental, so progress is visible mid-run
}

note(if (fails == 0L)
  "## GATE (a): PASS — the locked preview's primary-CF (and FA/PA/NA) rows reproduce at quoted precision for every example; CV deltas are the documented pre-fix legacy"
  else sprintf("## GATE (a): FAIL — %d gated cell(s) off at quoted precision; MUST-FIX in the package", fails))
writeLines(lines, report)
quit(status = if (fails == 0L) 0L else 1L)
