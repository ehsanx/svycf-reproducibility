# =====================================================================
# make_fixtures.R — generate the stored CERTIFIED-REFERENCE values used by
# tests/testthat/test-equivalence.R. Developer-only: needs the survey-tmle2
# working repo (env SVYTMLE_REF). The fixtures freeze the output of the
# reference codes/estimators.R (NOT the package) so the tests remain an
# independent regression gate for the package.
#   fixture ref_sim_glm.rds   : SL.glm-only, all arms (CV self-skips)
#   fixture ref_sim_full.rds  : default 3-learner library, all five arms
# =====================================================================
REF <- Sys.getenv("SVYTMLE_REF", "../survey-tmle2")
PKG <- Sys.getenv("SVYTMLE_PKG", ".")

.ref_file <- function(root, name) {
  for (p in file.path(root, c("codes", "R"), name)) if (file.exists(p)) return(p)
  stop(name, " not found under ", root)
}
suppressMessages({library(SuperLearner); library(survey); library(surveyCV); library(tmle)})
e_ref <- new.env(); sys.source(.ref_file(REF, "estimators.R"), envir = e_ref)
d_ref <- new.env(); sys.source(.ref_file(REF, "dgp.R"),        envir = d_ref)

pop <- d_ref$make_population("standard", "simple", truth_M = 1e4L)
obs <- d_ref$draw_sample(pop, sample_seed = 42L)
SEED <- 20260607L

ver <- list(
  R = as.character(getRversion()),
  pkgs = vapply(c("tmle", "SuperLearner", "survey", "surveyCV", "earth", "glmnet"),
                function(p) as.character(utils::packageVersion(p)), character(1)),
  generated = format(Sys.time(), tz = "UTC", usetz = TRUE),
  source = "survey-tmle2/codes/estimators.R (reference), draw: standard/simple pop_seed 20260606 sample_seed 42"
)

set.seed(SEED)
r1 <- e_ref$run_estimators(obs, learners = "SL.glm", V_cf = 5L, inner_cv_folds = 5L)
res1 <- r1$results; rownames(res1) <- NULL
saveRDS(list(results = res1, drow = r1$diagnostics$drow, seed = SEED,
             learners = "SL.glm", versions = ver),
        file.path(PKG, "tests", "testthat", "fixtures", "ref_sim_glm.rds"),
        version = 3)

LIB <- c("SL.glm", "SL.earth", "SL.glmnet")
set.seed(SEED)
r2 <- e_ref$run_estimators(obs, learners = LIB, V_cf = 5L, inner_cv_folds = 5L)
res2 <- r2$results; rownames(res2) <- NULL
saveRDS(list(results = res2, drow = r2$diagnostics$drow, seed = SEED,
             learners = LIB, versions = ver),
        file.path(PKG, "tests", "testthat", "fixtures", "ref_sim_full.rds"),
        version = 3)

cat("fixtures written:\n")
print(res1, digits = 8)
print(res2, digits = 8)
