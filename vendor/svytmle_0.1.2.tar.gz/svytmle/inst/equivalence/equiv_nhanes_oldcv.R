# =====================================================================
# Provenance confirmation for the CV-row exception in equiv_nhanes.R:
# the locked preview (2026-06-07) predates the reference engine's CV-arm
# fix (commit 86c9f81, 2026-06-08: unweighted domain nuisances). This
# script runs E3 with the PRE-fix engine text (survey-tmle2 commit
# c49e08f, 2026-06-07 — the engine generation that produced the preview)
# through the same prep as the as-run driver, and compares ALL FIVE arms
# to the locked RDS. Expected: every arm matches, INCLUDING the CV row
# the current engine moves — proving the CV delta in the main gate is
# engine-history, not a package bug.
#
# Usage:  git -C $SVYTMLE_REF show c49e08f:codes/estimators.R > <tmp>
#         is done here via system2(git).
# =====================================================================
REF <- Sys.getenv("SVYTMLE_REF", "../survey-tmle2")
PKG <- Sys.getenv("SVYTMLE_PKG", ".")
dir.create(file.path(PKG, "dev", "equivalence"), recursive = TRUE, showWarnings = FALSE)
SHA <- "c49e08f"

old_txt <- system2("git", c("-C", shQuote(REF), "show",
                            paste0(SHA, ":codes/estimators.R")), stdout = TRUE)
old_file <- tempfile(fileext = ".R")
writeLines(old_txt, old_file)

suppressMessages({library(SuperLearner); library(survey); library(surveyCV); library(tmle)})
e_old <- new.env(); sys.source(old_file, envir = e_old)

# --- replicate the as-run driver prep (Nhanes/R/03_run_estimators.R) ---
id <- "E3"
obs  <- readRDS(file.path(REF, "Nhanes", "analytic", paste0(id, "_imputed.rds")))
covs <- attr(obs, "covs"); sub <- which(obs$inpop)
covdf <- droplevels(obs[sub, covs, drop = FALSE])
mm <- model.matrix(~ ., data = covdf)[, -1, drop = FALSE]
wnames <- make.names(colnames(mm), unique = TRUE); colnames(mm) <- wnames
for (j in seq_along(wnames)) { obs[[wnames[j]]] <- NA_real_; obs[[wnames[j]]][sub] <- mm[, j] }
obs$strata <- obs$SDMVSTRA; obs$cluster <- obs$SDMVPSU; obs$weight <- obs$WTMEC_POOLED

set.seed(20260607L)
r <- e_old$run_estimators(obs, learners = c("SL.glm", "SL.earth", "SL.glmnet"),
                          V_cf = 5L, inner_cv_folds = 5L,
                          W_cols = wnames, nest = TRUE, inpop = obs$inpop)
rr <- r$results
crit <- qt(0.975, pmax(1, rr$df))
rr$lcl <- rr$b - crit * rr$se; rr$ucl <- rr$b + crit * rr$se

ref <- readRDS(file.path(REF, "Nhanes", "results", id, "estimators_all_arms.rds"))$results
lines <- c(sprintf("# old-engine (%s) confirmation, %s", SHA, id),
           sprintf("date: %s | R %s", format(Sys.time()), getRversion()), "")
fails <- 0L
for (k in seq_len(nrow(ref))) {
  j <- match(ref$method[k], rr$method)
  dmax <- max(abs(unlist(ref[k, c("b", "se", "lcl", "ucl")]) -
                  unlist(rr[j, c("b", "se", "lcl", "ucl")])))
  ok <- dmax == 0 && ref$df[k] == rr$df[j]
  if (!ok) fails <- fails + 1L
  lines <- c(lines, sprintf("- %s: max |delta| = %.3e, df %d vs %d -> %s",
                            ref$method[k], dmax, ref$df[k], rr$df[j],
                            if (ok) "IDENTICAL" else "DIFFERS"))
}
lines <- c(lines, "",
           if (fails == 0L)
             "## CONFIRMED: the pre-fix engine reproduces the locked preview bitwise, INCLUDING the CV row — the main gate's CV delta is engine history, not a package bug"
           else sprintf("## NOT CONFIRMED: %d arm(s) differ — investigate further", fails))
writeLines(lines, file.path(PKG, "dev", "equivalence", "equivalence_report_oldcv.md"))
cat(paste(lines, collapse = "\n"), "\n")
quit(status = if (fails == 0L) 0L else 1L)
