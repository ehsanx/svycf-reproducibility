# svytmle equivalence gates

This package's correctness claim is **numerical equivalence with the
paper's as-run pipeline** (the reference implementation in the
`survey-tmle2` working repository / the public
[Survey-TMLE-codes](https://github.com/ehsanx/Survey-TMLE-codes) mirror,
whose `R/estimators.R` is byte-identical). These scripts are the gate;
the testthat suite re-checks the simulation gate against frozen fixtures
on every run.

| Script | What it proves | Needs |
|---|---|---|
| `equiv_sim.R` | Gate (b): on a fixed-seed simulated draw, `svytmle(arms="all")` is **bitwise identical** to the reference `run_estimators()` (all five arms: b, se, df, CI, diagnostics; plus the DGP port). | the `survey-tmle2` repo (`SVYTMLE_REF`) |
| `equiv_nhanes.R` | Gate (a): with seed 20260607 and the default library, the package reproduces the locked five-arm NHANES preview (E1–E4) at quoted 4-dp precision for the primary Fully-Aware-CF row + the FA/PA/NA rows; full-precision deltas vs the locked RDS reported per arm; per-example package fits saved. The CV comparison row is report-only (see below). | `SVYTMLE_REF` + the NHANES analytic frames (~1–3 h) |
| `equiv_nhanes_oldcv.R` | The provenance of the one documented exception: the locked preview (2026-06-07) predates the reference engine's CV-arm refinement (commit `86c9f81`, 2026-06-08: CV nuisances fit UNWEIGHTED on real-data domains). This script reruns E3 with the pre-fix engine text (commit `c49e08f`) and shows it reproduces the locked preview **including the CV row** — so the main gate's CV delta is engine history, not a package bug. | `SVYTMLE_REF` with git history |
| `make_fixtures.R` | Regenerates the frozen reference fixtures used by `tests/testthat/test-equivalence.R` (runs the reference, not the package). | `SVYTMLE_REF` |

(Additional developer scratch scripts live in `tools/dev/`, which is not
shipped in the built package.)

Reports are written to `dev/equivalence/` (`equivalence_report_*.md`,
build-ignored). Policy: **any gated mismatch is a must-fix in the
package — tolerances are never widened.** The single CV-row exception is
deliberate, documented above, and backed by the old-engine
reproduction — validating the locked CV row would validate the superseded
estimator.

Environment note: the gates were run under the same local environment
that produced the locked NHANES preview (R 4.5.1; see `SESSIONINFO.md`
in the source repository), which is what makes bitwise comparison
meaningful. Under other package versions/BLAS builds, trailing digits
may differ.

Third-party reproduction: `equiv_sim.R` and `make_fixtures.R` accept
either reference layout via `SVYTMLE_REF` — the maintainer's working
repo (`codes/*.R`) or the public
[Survey-TMLE-codes](https://github.com/ehsanx/Survey-TMLE-codes) repo
(`R/*.R`); the engine files are byte-identical (SHA-256 in
`R/engine.R`'s header). The NHANES gate additionally needs the analytic
frames, which are rebuilt from public NHANES files by the public repo's
`nhanes/R/00–02` pipeline.
