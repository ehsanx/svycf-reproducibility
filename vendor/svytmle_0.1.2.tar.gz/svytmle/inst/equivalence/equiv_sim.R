# =====================================================================
# Equivalence gate (b): fixed-seed simulated draw —
#   svytmle::svytmle(arms = "all")  ==  the reference
#   survey-tmle2/codes/estimators.R::run_estimators()  (numerically).
#
# PASS criterion: IDENTICAL numbers (bitwise). Any mismatch is a MUST-FIX
# in the package, never a tolerance to widen.
#
# Usage:  Rscript inst/equivalence/equiv_sim.R
#   env SVYTMLE_REF = path to the survey-tmle2 working repo
#       SVYTMLE_PKG = path to the package source (loaded with pkgload if
#                     svytmle is not installed)
# Writes equivalence_report_sim.md next to the package root; exits nonzero
# on failure.
# =====================================================================
REF <- Sys.getenv("SVYTMLE_REF", "../survey-tmle2")
PKG <- Sys.getenv("SVYTMLE_PKG", ".")
dir.create(file.path(PKG, "dev", "equivalence"), recursive = TRUE, showWarnings = FALSE)

# ---- the reference, sourced untouched into private envs ----
# (works against either the working repo layout, codes/*.R, or the public
#  Survey-TMLE-codes layout, R/*.R — the files are byte-identical)
.ref_file <- function(root, name) {
  for (p in file.path(root, c("codes", "R"), name)) if (file.exists(p)) return(p)
  stop(name, " not found under ", root)
}
suppressMessages({library(SuperLearner); library(survey); library(surveyCV); library(tmle)})
e_ref <- new.env(); sys.source(.ref_file(REF, "estimators.R"), envir = e_ref)
d_ref <- new.env(); sys.source(.ref_file(REF, "dgp.R"),        envir = d_ref)

# ---- the package ----
if (!requireNamespace("svytmle", quietly = TRUE)) {
  pkgload::load_all(PKG, quiet = TRUE)
} else library(svytmle)

LIB  <- c("SL.glm", "SL.earth", "SL.glmnet")   # default NHANES library
SEED <- 20260607L                              # reference seed

lines <- c("# svytmle equivalence report — gate (b): simulated draw",
           sprintf("date: %s | R %s", format(Sys.time()), getRversion()),
           sprintf("library: %s | seed: %d | scenario: standard/simple, sample_seed 42",
                   paste(LIB, collapse = "+"), SEED), "")
fails <- 0L
note <- function(...) { msg <- sprintf(...); cat(msg, "\n"); lines <<- c(lines, msg) }
chk  <- function(ok, what) {
  note("- %s: %s", what, if (ok) "PASS" else "**FAIL**")
  if (!ok) fails <<- fails + 1L
  ok
}

# ---- 1. DGP port cross-check: package draw == reference draw, bitwise ----
pop_ref <- d_ref$make_population("standard", "simple", truth_M = 1e4L)
obs     <- d_ref$draw_sample(pop_ref, sample_seed = 42L)
pop_pkg <- make_population("standard", "simple", truth_M = 1e4L)
obs_pkg <- draw_sample(pop_pkg, sample_seed = 42L)
chk(identical(obs, obs_pkg), "DGP port: draw_sample identical (data + attributes)")
chk(identical(pop_ref$truth, pop_pkg$truth), "DGP port: population truth identical")

# ---- 2. reference engine on the draw ----
set.seed(SEED)
ref <- e_ref$run_estimators(obs, learners = LIB, V_cf = 5L, inner_cv_folds = 5L)
a <- ref$results; rownames(a) <- NULL

# ---- 3. package on the same draw, via the public API ----
des <- svydesign(ids = ~cluster, strata = ~strata, weights = ~weight, data = obs)
set.seed(SEED)
fit <- svytmle(des, outcome = "Y", treatment = "A",
               covariates = c("L1", "L2", "L3", "L4"),
               learners = LIB, arms = "all")
b <- fit$results

# ---- 4. compare ----
chk(identical(a$method, b$method), "arm order identical")
for (col in c("b", "se", "df")) {
  same <- identical(a[[col]], b[[col]])
  if (!same) note("  max |delta %s| = %.3e", col, max(abs(a[[col]] - b[[col]])))
  chk(same, sprintf("column '%s' bitwise identical", col))
}
# CI columns: recompute the CI on the reference side (the locked
# NHANES driver's formula) and compare bitwise
crit <- qt(0.975, pmax(1, a$df))
chk(identical(a$b - crit * a$se, fit$results$lcl), "lcl bitwise identical")
chk(identical(a$b + crit * a$se, fit$results$ucl), "ucl bitwise identical")
# diagnostics row
da <- ref$diagnostics$drow; db <- fit$diagnostics
chk(identical(da, db), "diagnostics drow identical")

note("")
note("reference results:")
lines <- c(lines, "", "```", capture.output(print(cbind(a, lcl = a$b - crit*a$se, ucl = a$b + crit*a$se), digits = 10)), "```")
lines <- c(lines, "", "package results:", "```", capture.output(print(b, digits = 10)), "```")

note("")
note(if (fails == 0L) "## GATE (b): PASS — package is numerically identical to the reference"
     else sprintf("## GATE (b): FAIL — %d mismatch(es); MUST-FIX in the package", fails))
writeLines(lines, file.path(PKG, "dev", "equivalence", "equivalence_report_sim.md"))
quit(status = if (fails == 0L) 0L else 1L)
