# =====================================================================
# design-utils.R — extract the raw design variables from a survey::svydesign
#
# The reference pipeline fed the RAW strata / PSU-id / weight columns to the
# engine (survey-tmle2/Nhanes/R/03_run_estimators.R). survey::svydesign
# transforms its inputs internally (under nest = TRUE the PSU ids are
# relabelled to stratum.psu factors, and weights(design) = 1/(1/w) carries an
# ulp-level double-inversion error), so to reproduce the primary estimator
# exactly we recover the ORIGINAL columns by re-evaluating the formulas
# stored in design$call against design$variables. When that is impossible
# (a design built programmatically), we fall back to the design object's
# internal representations. On the fallback path the primary cf arm (and
# fa/pa/na) keep their PSU partition, folds, SE and df (folds key on the
# (stratum, PSU) pair; verified in tests) up to ulp-level weight rounding —
# but survey RELABELS nested PSU ids ("1.1", "1.2", ...), which can flip the
# cv comparison arm's internal folds.svy clustering from its raw-id
# behaviour, and once the cv arm diverges every arm AFTER it in an
# arms-including-"cv" run sees a shifted RNG stream. The warning says so.
# =====================================================================

# is `design` a plain (linearization) svydesign of the expected class?
# allow_replicate = TRUE permits a svyrep.design (used by variance = "replicate").
.check_design <- function(design, allow_replicate = FALSE) {
  if (inherits(design, "svyrep.design")) {
    if (allow_replicate) return(invisible(TRUE))
    stop("svytmle() needs a linearization design built with survey::svydesign(); ",
         "replicate-weight designs (svrepdesign) need variance = \"replicate\".",
         call. = FALSE)
  }
  if (!inherits(design, "survey.design"))
    stop("`design` must be a survey design object built with survey::svydesign().",
         call. = FALSE)
  if (!is.null(design$pps) && !identical(design$pps, FALSE))
    stop("PPS-without-replacement designs are outside the supported scope of the ",
         "estimator (see the paper's Section 6 scope statement).", call. = FALSE)
  if (!is.null(design$postStrata))
    stop("Calibrated / post-stratified designs are outside the supported scope of ",
         "the estimator (see the paper's Section 6 scope statement). Supply the ",
         "uncalibrated design.", call. = FALSE)
  cl <- design$call
  if (is.call(cl)) {
    fname <- deparse(cl[[1]])
    if (fname %in% c("subset", "subset.survey.design"))
      stop("`design` looks like a subset() of a survey design. The primary ",
           "estimator computes the domain variance on the FULL design: pass the ",
           "full design and select the analytic domain with the `subset` ",
           "argument of svytmle().", call. = FALSE)
  }
  if (!is.null(design$fpc$popsize))
    warning("`design` carries finite-population corrections; the primary ",
            "estimator uses the no-FPC (with-replacement first stage) variance, ",
            "which the paper's Web Appendix F shows is calibrated (an FPC ",
            "induces under-coverage for the super-population ATE). The FPC is ",
            "ignored.", call. = FALSE)
  invisible(TRUE)
}

# recover raw strata / first-stage PSU id / weight vectors
.design_extract <- function(design) {
  vars <- design$variables
  n <- nrow(vars)
  out <- NULL

  cl <- design$call
  recoverable <- is.call(cl) &&
    deparse(cl[[1]]) %in% c("svydesign", "survey::svydesign")
  if (recoverable) {
    # normalize positional and partially-matched arguments (svydesign(~psu, ...)
    # records ids POSITIONALLY; without this, cl$ids would be NULL and every
    # row would silently become its own PSU)
    cl <- tryCatch(match.call(survey::svydesign, cl), error = function(e) cl)
  }
  if (recoverable) {
    out <- tryCatch({
      get_col <- function(arg, what) {
        if (is.null(arg)) return(NULL)
        f <- eval(arg, envir = baseenv())   # only formula LITERALS evaluate here
        if (!inherits(f, "formula")) return(NA)  # non-literal -> fallback
        v <- all.vars(f)
        if (length(v) == 0) return(NULL)         # ~1 / ~0: no clustering/strata
        if (what == "ids" && length(v) > 1) {
          warning("multi-stage ids in the design; only the FIRST-stage PSU (`",
                  v[1], "`) is used, per the with-replacement ",
                  "first-stage approximation.", call. = FALSE)
        }
        if (!v[1] %in% names(vars)) return(NA)   # column not present -> fallback
        vars[[v[1]]]
      }
      ids_col    <- get_col(cl$ids,     "ids")
      strata_col <- get_col(cl$strata,  "strata")
      w_col      <- get_col(cl$weights, "weights")
      if (identical(ids_col, NA) || identical(strata_col, NA) || identical(w_col, NA))
        NULL
      else {
        if (is.null(w_col)) w_col <- as.numeric(stats::weights(design, "sampling"))
        # sanity: recovered weights must agree with the design's probabilities
        wd <- as.numeric(stats::weights(design, "sampling"))
        if (max(abs(w_col - wd) / pmax(wd, 1e-300)) > 1e-6) NULL
        else list(
          strata  = if (is.null(strata_col)) rep(1L, n) else strata_col,
          cluster = if (is.null(ids_col)) seq_len(n) else ids_col,
          weight  = w_col,
          source  = "call"
        )
      }
    }, error = function(e) NULL)
  }

  if (is.null(out)) {
    warning("could not recover the original design variables from `design$call`; ",
            "falling back to the design object's internal strata/PSU/weight ",
            "representations. The primary cross-fitted arm (and the fa/pa/na ",
            "arms, when they run before \"cv\") is unaffected up to ulp-level ",
            "weight rounding. BUT survey relabels nested PSU ids internally, ",
            "which can change the \"cv\" comparison arm's internal fold ",
            "clustering on designs whose PSU ids repeat across strata -- and ",
            "any arm run after a diverged \"cv\" arm sees a shifted RNG stream. ",
            "For exact reproduction, build the design with literal formulas: ",
            "svydesign(ids = ~psu, strata = ~stratum, weights = ~w, ...).",
            call. = FALSE)
    out <- list(
      strata  = design$strata[, 1],
      cluster = design$cluster[, 1],
      weight  = as.numeric(stats::weights(design, "sampling")),
      source  = "internal"
    )
  }
  out
}

# replicate-weight SE of psi: the replicate variance of the weighted (Hajek) mean
# of the per-unit influence function. Mirrors .se_des()/. aipw_jkn(): the design
# SE of psi IS the SE of the weighted mean of its EIF, so the replicate analogue
# is withReplicates() of that Hajek mean (shift-invariant, so the centered EIF and
# eif + psi give the same SE). Domain path subsets the replicate design.
.se_replicate <- function(eif, rep_des, inpop = NULL) {
  if (is.null(inpop)) {
    rep_des$variables$.eif <- eif
    est <- withReplicates(rep_des, function(wts, dat) sum(wts * dat$.eif) / sum(wts))
    return(list(se = as.numeric(SE(est)), df = survey::degf(rep_des)))
  }
  eif_full <- numeric(length(inpop)); eif_full[inpop] <- eif
  rep_des$variables$.eif   <- eif_full
  rep_des$variables$.inpop <- inpop
  df_dom <- survey::degf(subset(rep_des, .inpop))
  est <- tryCatch(
    withReplicates(subset(rep_des, .inpop),
                   function(wts, dat) sum(wts * dat$.eif) / sum(wts)),
    error = function(e) NULL)
  if (is.null(est))
    est <- withReplicates(rep_des, function(wts, dat)
      sum(wts * dat$.eif * dat$.inpop) / sum(wts * dat$.inpop))
  list(se = as.numeric(SE(est)), df = df_dom)
}

# resolve a subset specification to a full-length logical (or NULL)
.resolve_subset <- function(subset, vars) {
  if (is.null(subset)) return(NULL)
  inpop <-
    if (inherits(subset, "formula")) {
      if (length(subset) != 2)
        stop("`subset` formula must be one-sided, e.g. ~ inpop or ~ age >= 20.",
             call. = FALSE)
      eval(subset[[2]], envir = vars, enclos = environment(subset))
    } else subset
  if (!is.logical(inpop) || length(inpop) != nrow(vars))
    stop("`subset` must be NULL, a one-sided formula over the design variables, ",
         "or a logical vector with one entry per row of the design.", call. = FALSE)
  if (anyNA(inpop))
    stop("`subset` evaluates to NA for ", sum(is.na(inpop)), " rows; resolve ",
         "missingness in the domain definition explicitly.", call. = FALSE)
  if (!any(inpop)) stop("`subset` selects no rows.", call. = FALSE)
  if (all(inpop)) return(NULL)   # whole sample: primary whole-sample path
  inpop
}

# validate/convert a treatment or outcome column to 0/1 numeric
.binary01 <- function(x, what, rows) {
  v <- x[rows]
  if (is.logical(x)) x <- as.numeric(x)
  else if (is.factor(x)) {
    if (nlevels(droplevels(factor(v))) > 2)
      stop("`", what, "` has more than two levels on the analytic domain.",
           call. = FALSE)
    lev <- levels(x)
    if (length(lev) != 2)
      stop("`", what, "` must be a two-level factor (or 0/1 numeric).", call. = FALSE)
    message("`", what, "`: treating factor level '", lev[2], "' as 1 and '",
            lev[1], "' as 0.")
    x <- as.numeric(x == lev[2])
  }
  if (!is.numeric(x))
    stop("`", what, "` must be numeric 0/1, logical, or a two-level factor.",
         call. = FALSE)
  if (anyNA(x[rows]))
    stop("`", what, "` is missing for ", sum(is.na(x[rows])), " rows of the ",
         "analytic domain; svytmle() does not impute (see the package ",
         "vignettes for a multiple-imputation workflow).", call. = FALSE)
  if (!all(x[rows] %in% c(0, 1)))
    stop("`", what, "` must be coded 0/1 on the analytic domain (binary ",
         "outcomes/treatments only in this version).", call. = FALSE)
  x
}

# validate a continuous (family = "gaussian") outcome: numeric, complete on the
# domain. NOT a primary path -- the gaussian branch is a separate, opt-in estimator
# (the engine rescales Y to [0,1] for the logistic fluctuation; see engine.R).
.num_outcome <- function(x, what, rows) {
  if (is.logical(x)) x <- as.numeric(x)
  if (!is.numeric(x))
    stop("`", what, "` must be numeric for family = \"gaussian\".", call. = FALSE)
  if (anyNA(x[rows]))
    stop("`", what, "` is missing for ", sum(is.na(x[rows])), " rows of the ",
         "analytic domain; svytmle() does not impute (see the package ",
         "vignettes for a multiple-imputation workflow).", call. = FALSE)
  x
}
