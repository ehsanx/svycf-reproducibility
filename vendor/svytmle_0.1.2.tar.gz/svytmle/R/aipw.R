# =====================================================================
# aipw.R — survey-weighted AIPW comparator (svyaipw)
#
# PROVENANCE: byte-faithful port of the reference AIPW benchmark
#   (survey-tmle2/codes/arc_runs/R15_aipw_benchmark/aipw_helpers.R). The ONLY
#   changes are that the canonical building blocks (.sl, make_cf_folds, .se_des)
#   are taken from this package's engine.R (NAMESPACE) instead of being sourced,
#   and [PKG-EDIT] (2026-09-24) the opt-in `nuisance_weights = "survey"` mode for
#   the AIPW-CF out-of-fold fits (engine.R .cf_train_weights). The default
#   "unweighted" is the reference code path, verified bit-for-bit.
#
# An independent, literature-standard estimator (NOT TMLE, NOT the primary
# estimator): survey-weighted augmented-IPW (one-step / DML), with the same
# single-fit-vs-cross-fit nuisance axis and the same design-based variance as
# the primary arms, plus a survey JKn (delete-one-PSU) replicate SE.
#
#   AIPW-SF  WEIGHTED single-fit nuisances (weights normalized to mean 1 for the
#            fits only; raw survey weights diverge glm's IRLS), in-sample predict.
#   AIPW-CF  UNWEIGHTED out-of-fold nuisances over make_cf_folds() -- the engine
#            CF protocol (valid under sampling ignorability S _||_ (A,Y) | C).
#   Point estimate: Hajek-weighted AIPW pseudo-outcome.
#   Variance two ways: se_jkn (JKn replicate, nuisances frozen) and se_lin
#            (Eq-8 design linearization of the centered pseudo-outcome) -- the
#            latter is the CI basis (apples-to-apples with the primary arms).
# =====================================================================

# Q clamp used by the engine before targeting (estimators.R); kept identical.
.AIPW_Q_CLAMP <- 1e-3

# ---- JKn replicate SE of the Hajek AIPW mean (nuisances frozen) -------------
.aipw_jkn <- function(D, strata, cluster, weight, nest = FALSE, inpop = NULL) {
  if (is.null(inpop)) {                       # whole-sample path
    dat <- data.frame(D = D, strata = strata, cluster = cluster, weight = weight)
    des <- svydesign(ids = ~cluster, strata = ~strata, weights = ~weight,
                     data = dat, nest = nest)
    rep_des <- as.svrepdesign(des, type = "JKn")
    est <- withReplicates(rep_des, function(wts, dat) sum(wts * dat$D) / sum(wts))
    return(list(se = as.numeric(SE(est)), df = survey::degf(des), mode = "full"))
  }
  # domain path: replicate design on the FULL design, then subset to the domain
  D_full <- numeric(length(inpop)); D_full[inpop] <- D
  dat <- data.frame(D = D_full, strata = strata, cluster = cluster,
                    weight = weight, .inpop = inpop)
  des <- svydesign(ids = ~cluster, strata = ~strata, weights = ~weight,
                   data = dat, nest = nest)
  rep_des <- as.svrepdesign(des, type = "JKn")
  df_dom  <- survey::degf(subset(des, .inpop))
  out <- tryCatch({
    sub_rep <- subset(rep_des, .inpop)
    est <- withReplicates(sub_rep, function(wts, dat) sum(wts * dat$D) / sum(wts))
    list(se = as.numeric(SE(est)), df = df_dom, mode = "subset_repdes")
  }, error = function(e) NULL)
  if (is.null(out)) {
    est <- withReplicates(rep_des, function(wts, dat)
      sum(wts * dat$D * dat$.inpop) / sum(wts * dat$.inpop))
    out <- list(se = as.numeric(SE(est)), df = df_dom, mode = "domain_zeroed_full")
  }
  out
}

# ---- aipw_arms(): AIPW-SF + AIPW-CF, shaped like run_estimators() -----------
aipw_arms <- function(obs, learners = "SL.glm", g_floor = 0.05, V_cf = 5L,
                      W_cols = c("L1", "L2", "L3", "L4"),
                      nest = FALSE, inpop = NULL,
                      nuisance_weights = c("unweighted", "survey")) {   # [PKG-EDIT]
  nuisance_weights <- match.arg(nuisance_weights)
  nw_survey <- identical(nuisance_weights, "survey")
  sub <- if (is.null(inpop)) seq_len(nrow(obs)) else which(inpop)
  d   <- obs[sub, , drop = FALSE]
  n   <- nrow(d); w <- d$weight
  W   <- d[, W_cols, drop = FALSE]
  XA  <- d[, c("A", W_cols), drop = FALSE]
  Xa1 <- data.frame(A = 1, W); Xa0 <- data.frame(A = 0, W)

  ## ---- AIPW-SF: WEIGHTED single-fit, in-sample predictions (weights mean-1) --
  w_fit <- w / mean(w)
  qf_sf <- .sl(d$Y, XA, weights = w_fit, learners)
  gf_sf <- .sl(d$A, W,  weights = w_fit, learners)
  Q1_sf_raw <- qf_sf(Xa1); Q0_sf_raw <- qf_sf(Xa0); g_sf_raw <- gf_sf(W)

  ## ---- AIPW-CF: UNWEIGHTED out-of-fold (engine CF protocol) -----------------
  fold <- make_cf_folds(d$strata, d$cluster, V_cf)
  Q1_cf_raw <- Q0_cf_raw <- g_cf_raw <- numeric(n)
  for (v in sort(unique(fold))) {
    tr <- which(fold != v); ho <- which(fold == v)
    wt <- if (nw_survey) .cf_train_weights(w, d$strata, d$cluster, fold, v) else NULL   # [PKG-EDIT]
    qf <- .sl(d$Y[tr], XA[tr, ], weights = wt, learners)   # default UNWEIGHTED (ignorability)
    gf <- .sl(d$A[tr], W[tr, ],  weights = wt, learners)
    Q1_cf_raw[ho] <- qf(Xa1[ho, ]); Q0_cf_raw[ho] <- qf(Xa0[ho, ])
    g_cf_raw[ho]  <- gf(W[ho, ])
  }

  clamp <- function(x, lo, hi) pmin(pmax(x, lo), hi)
  g_sf <- clamp(g_sf_raw, g_floor, 1 - g_floor)
  g_cf <- clamp(g_cf_raw, g_floor, 1 - g_floor)
  Q1s  <- clamp(Q1_sf_raw, .AIPW_Q_CLAMP, 1 - .AIPW_Q_CLAMP)
  Q0s  <- clamp(Q0_sf_raw, .AIPW_Q_CLAMP, 1 - .AIPW_Q_CLAMP)
  Q1c  <- clamp(Q1_cf_raw, .AIPW_Q_CLAMP, 1 - .AIPW_Q_CLAMP)
  Q0c  <- clamp(Q0_cf_raw, .AIPW_Q_CLAMP, 1 - .AIPW_Q_CLAMP)

  ## ---- one arm: Hajek AIPW point + JKn replicate SE + Eq-8 linearized SE ----
  one_arm <- function(Q1, Q0, g1, label) {
    D   <- d$A * (d$Y - Q1) / g1 - (1 - d$A) * (d$Y - Q0) / (1 - g1) + Q1 - Q0
    psi <- sum(w * D) / sum(w)
    jk <- if (is.null(inpop))
      .aipw_jkn(D, d$strata, d$cluster, w, nest = nest)
    else
      .aipw_jkn(D, obs$strata, obs$cluster, obs$weight, nest = nest, inpop = inpop)
    sl <- if (is.null(inpop))
      .se_des(D - psi, d$strata, d$cluster, w, clustered = TRUE)
    else
      .se_des(D - psi, obs$strata, obs$cluster, obs$weight, clustered = TRUE,
              nest = nest, inpop = inpop)
    list(row = data.frame(method = label, b = psi, se_jkn = jk$se,
                          se_lin = sl$se, df = sl$df, stringsAsFactors = FALSE),
         D_centered = D - psi, jkn_mode = jk$mode, df_jkn = jk$df)
  }

  sf <- one_arm(Q1s, Q0s, g_sf, "AIPW-SF")
  cf <- one_arm(Q1c, Q0c, g_cf, "AIPW-CF")

  drow <- data.frame(
    g_sf_min = min(g_sf), g_sf_max = max(g_sf),
    g_cf_min = min(g_cf), g_cf_max = max(g_cf),
    g_sf_outside_floor = mean(g_sf_raw < g_floor | g_sf_raw > 1 - g_floor),
    g_cf_outside_floor = mean(g_cf_raw < g_floor | g_cf_raw > 1 - g_floor),
    cf_V_eff = attr(fold, "V_eff"),
    df_jkn = sf$df_jkn, jkn_mode = sf$jkn_mode,
    df_jkn_cf = cf$df_jkn, jkn_mode_cf = cf$jkn_mode,
    g_floor = g_floor, stringsAsFactors = FALSE)

  list(results = rbind(sf$row, cf$row),
       diagnostics = list(drow = drow, D_sf = sf$D_centered, D_cf = cf$D_centered,
                          nuisance_weights = nuisance_weights))   # [PKG-EDIT] recorded
}

#' Survey-weighted AIPW comparator (single-fit and cross-fit)
#'
#' A first-class, literature-standard *comparator* to [svytmle()]: survey-weighted
#' augmented inverse-probability weighting (AIPW / one-step DML) for the
#' population average treatment effect, with the same single-fit-vs-cross-fit
#' nuisance axis and the same design-based (Equation-8) variance as the
#' [svytmle()] arms, plus a survey JKn replicate SE. AIPW is **not** the
#' recommended estimator; use it to check that the TMLE findings are not
#' method-specific.
#'
#' The reported `se` (and hence the CI) is the Equation-8 design linearization SE
#' (`se_lin`), apples-to-apples with [svytmle()]; the JKn replicate SE is kept in
#' `se_jkn`. The interface mirrors [svytmle()] (a full [survey::svydesign()],
#' domains via `subset`).
#'
#' @inheritParams svytmle
#' @param arms which protocols to return: a subset of `c("sf", "cf")` (default
#'   both; `"sf"` = single-fit, `"cf"` = cross-fit).
#' @param family currently `"binomial"` only (binary outcome); a continuous
#'   AIPW branch is not yet implemented.
#' @param nuisance_weights `"unweighted"` (default) or `"survey"` for the AIPW-CF
#'   out-of-fold nuisance fits; see [svytmle()]. The AIPW-SF single fit is always
#'   weighted (weights normalised to mean 1), as before.
#'
#' @return An object of class `c("svyaipw", "svytmle")`: `results` has one row
#'   per protocol (`method`, `b`, `se` = `se_lin`, `se_jkn`, `df`, `lcl`, `ucl`).
#'   `print()`, `coef()`, `confint()`, `as.data.frame()` work as for [svytmle()];
#'   the cross-fit row (`AIPW-CF`) is treated as primary.
#'
#' @seealso [svytmle()] (the primary estimator); [delta_rr_or()].
#' @examples
#' \donttest{
#' pop <- make_population("standard", "simple", truth_M = 1e4L)
#' des <- survey::svydesign(ids = ~cluster, strata = ~strata, weights = ~weight,
#'                          data = draw_sample(pop, sample_seed = 7L))
#' set.seed(1)
#' svyaipw(des, "Y", "A", c("L1", "L2", "L3", "L4"), learners = "SL.glm")
#' }
#' @export
svyaipw <- function(design, outcome, treatment, covariates,
                    learners = c("SL.glm", "SL.earth", "SL.glmnet"),
                    subset = NULL, arms = c("sf", "cf"),
                    family = "binomial",
                    cf_folds = 5L, g_bound = 0.05, level = 0.95,
                    nuisance_weights = c("unweighted", "survey")) {
  nuisance_weights <- match.arg(nuisance_weights)
  if (!identical(family, "binomial"))
    stop("svyaipw() currently supports family = \"binomial\" (binary outcome); ",
         "continuous-outcome AIPW is not yet implemented.", call. = FALSE)
  if (!is.numeric(level) || length(level) != 1 || level <= 0 || level >= 1)
    stop("`level` must be a single number in (0, 1).", call. = FALSE)
  if (!is.numeric(g_bound) || length(g_bound) != 1 || g_bound <= 0 || g_bound >= 0.5)
    stop("`g_bound` must be a single number in (0, 0.5).", call. = FALSE)
  arms <- match.arg(arms, c("sf", "cf"), several.ok = TRUE)
  .check_learners(learners)
  .check_nuisance_learners(learners, nuisance_weights)
  if (identical(nuisance_weights, "survey") && !"cf" %in% arms)
    warning("nuisance_weights = \"survey\" affects only the AIPW-CF fits (AIPW-SF is always weighted); ",
            "it has no effect on the requested arms.", call. = FALSE)

  prep <- .prepare_engine_input(design, outcome, treatment, covariates,
                                subset = subset, family = "binomial")
  ext <- prep$ext; rows <- prep$rows

  a  <- aipw_arms(prep$obs, learners = learners, g_floor = g_bound, V_cf = cf_folds,
                  W_cols = prep$wnames, nest = TRUE, inpop = prep$inpop,
                  nuisance_weights = nuisance_weights)
  rr   <- a$results
  want <- unname(c(sf = "AIPW-SF", cf = "AIPW-CF")[arms])
  rr   <- rr[rr$method %in% want, , drop = FALSE]
  rr$se <- rr$se_lin                       # CI basis = Eq-8 linearized SE
  crit <- qt(1 - (1 - level) / 2, pmax(1, rr$df))
  rr$lcl <- rr$b - crit * rr$se
  rr$ucl <- rr$b + crit * rr$se
  rr <- rr[, c("method", "b", "se", "se_jkn", "se_lin", "df", "lcl", "ucl")]
  rownames(rr) <- NULL

  structure(list(
    results     = rr,
    diagnostics = a$diagnostics$drow,
    family      = "binomial",
    estimator   = "aipw",
    call        = match.call(),
    outcome     = outcome,
    treatment   = treatment,
    covariates  = prep$covariates,
    covariate_columns = prep$wnames,
    learners    = learners,
    arms        = arms,
    level       = level,
    g_bound     = g_bound,
    cf_folds    = cf_folds,
    nuisance_weights = nuisance_weights,
    n           = prep$n_full,
    n_domain    = length(rows),
    n_psu       = length(unique(paste(ext$strata[rows], ext$cluster[rows]))),
    n_strata    = length(unique(ext$strata[rows])),
    extraction  = ext$source
  ), class = c("svyaipw", "svytmle"))
}
