# =====================================================================
# methods.R — print/summary/coef/confint for svytmle fits
# =====================================================================

# the primary row: Fully-Aware-CF (primary) when present, else AIPW-CF (the
# comparator's cross-fit arm), else the first arm.
.primary_row <- function(x) {
  i <- match("Fully-Aware-CF", x$results$method)
  if (is.na(i)) i <- match("AIPW-CF", x$results$method)
  if (is.na(i)) 1L else i
}

#' @export
print.svytmle <- function(x, digits = 4, ...) {
  rr  <- x$results
  fam <- if (identical(x$family, "gaussian")) "mean difference" else "risk difference"
  est <- if (identical(x$estimator, "aipw"))
    "survey-weighted AIPW (comparator)" else "survey-weighted TMLE"
  vlab <- if (identical(x$variance, "replicate")) {
    rt <- if (is.null(x$replicate_type) || is.na(x$replicate_type)) "replicate" else x$replicate_type
    sprintf("replicate-weight variance (%s)", rt)
  } else "design-based linearization variance"
  struct <- if (identical(x$extraction, "svrep"))
    sprintf("replicate-weight design, %d obs", x$n)
  else
    sprintf("%d PSUs in %d strata", x$n_psu, x$n_strata)
  dom <- if (x$n_domain < x$n) sprintf(" (analytic domain n = %d)", x$n_domain) else ""
  cat(sprintf(
    "svytmle: %s of the population ATE (%s)\n  outcome '%s' ~ treatment '%s' | %d covariate column(s)\n  n = %d%s; %s; %s\n  learners: %s\n\n",
    est, fam, x$outcome, x$treatment, length(x$covariate_columns),
    x$n, dom, struct, vlab,
    paste0(paste(x$learners, collapse = " + "),
           if (identical(x$nuisance_weights, "survey") &&
               any(rr$method %in% c("Fully-Aware-CF", "Fully-Aware-CV", "AIPW-CF")))
             " (CF/CV nuisances survey-weighted)" else "")))
  out <- rr[, intersect(c("method", "b", "se", "se_jkn", "df", "lcl", "ucl"),
                        names(rr)), drop = FALSE]
  num <- vapply(out, is.numeric, logical(1))
  out[num] <- lapply(out[num], function(z) round(z, digits))
  print(out, row.names = FALSE)
  i   <- .primary_row(x)
  lab <- if (identical(x$estimator, "aipw"))
    (if (rr$method[i] == "AIPW-CF")
       "Primary AIPW cross-fit estimate (comparator, not the primary TMLE)"
     else "AIPW estimate (comparator)")
  else if ("Fully-Aware-CF" %in% rr$method)
    "Primary (cross-fitted) estimate"
  else
    "Estimate (NOT the primary cross-fitted arm; rerun with arms = \"cf\")"
  cat(sprintf(
    "\n%s: %s = %.*f, %g%% CI [%.*f, %.*f] (t, df = %d)\n",
    lab, rr$method[i], digits, rr$b[i], 100 * x$level,
    digits, rr$lcl[i], digits, rr$ucl[i], rr$df[i]))
  invisible(x)
}

#' @export
summary.svytmle <- function(object, ...) {
  structure(list(fit = object), class = "summary.svytmle")
}

#' @export
print.summary.svytmle <- function(x, digits = 4, ...) {
  f <- x$fit
  print(f, digits = digits)
  d <- f$diagnostics
  if (is.data.frame(d) && nrow(d) == 1 && ncol(d) > 0) {
    cat("\nDiagnostics:\n")
    if (!is.null(d$eps_cf))
      cat(sprintf("  CF targeting |epsilon| max: %.4g; out-of-fold g range: [%.3f, %.3f]; effective V: %d\n",
                  d$eps_cf, d$g_cf_min, d$g_cf_max, d$cf_V_eff))
    if (!is.null(d$eps_fa))
      cat(sprintf("  FA targeting |epsilon| max: %.4g; fitted g range: [%.3f, %.3f]\n",
                  d$eps_fa, d$g_fa_min, d$g_fa_max))
    cat(sprintf("  propensity truncation bound: [%.3g, %.3g]\n",
                f$g_bound, 1 - f$g_bound))
  }
  invisible(x)
}

#' @export
coef.svytmle <- function(object, ...) {
  i <- .primary_row(object)
  stats::setNames(object$results$b[i], object$results$method[i])
}

#' @export
confint.svytmle <- function(object, parm, level = NULL, ...) {
  rr <- object$results
  use_level <- if (is.null(level)) object$level else level
  if (!is.numeric(use_level) || length(use_level) != 1 ||
      use_level <= 0 || use_level >= 1)
    stop("`level` must be a single number in (0, 1).", call. = FALSE)
  # re-leveling needs no refit: the t reference uses the (fixed) design df, so a
  # new level just rescales the half-width via qt(level, df).
  if (isTRUE(all.equal(use_level, object$level))) {
    lo <- rr$lcl; hi <- rr$ucl
  } else {
    crit <- stats::qt(1 - (1 - use_level) / 2, pmax(1, rr$df))
    lo <- rr$b - crit * rr$se; hi <- rr$b + crit * rr$se
  }
  m <- cbind(lo, hi)
  rownames(m) <- rr$method
  colnames(m) <- paste0(100 * c((1 - use_level) / 2, 1 - (1 - use_level) / 2), " %")
  if (!missing(parm)) {
    codes <- c(fa = "Fully-Aware", pa = "Partially-Aware", na = "Non-Aware",
               cv = "Fully-Aware-CV", cf = "Fully-Aware-CF",
               sf = "AIPW-SF", aipw_cf = "AIPW-CF")
    parm <- ifelse(parm %in% names(codes), codes[parm], parm)
    bad <- setdiff(parm, rownames(m))
    if (length(bad))
      stop("unknown arm(s) ", paste(sQuote(bad), collapse = ", "),
           "; available: ", paste(rownames(m), collapse = ", "), call. = FALSE)
    m <- m[parm, , drop = FALSE]
  }
  m
}

#' @export
as.data.frame.svytmle <- function(x, ...) {
  rr <- x$results
  out <- data.frame(method = rr$method, estimate = rr$b, se = rr$se,
                    df = rr$df, conf.low = rr$lcl, conf.high = rr$ucl,
                    level = x$level, stringsAsFactors = FALSE)
  if (!is.null(rr$fmi)) out$fmi <- rr$fmi          # MI fits
  if (!is.null(rr$se_jkn)) out$se_jkn <- rr$se_jkn # AIPW fits
  out
}

#' Propensity overlap / positivity diagnostic from a fitted survey-TMLE
#'
#' Summarizes the estimated propensity scores stored by a [svytmle()] fit (the
#' single-fit `g_fa` and out-of-fold cross-fit `g_cf`): the range and the share
#' of units within the truncation bound `g_bound` of 0 or 1 (the positivity
#' "mass at the floor" the E4 example highlights).
#'
#' @param object a fitted [svytmle()] object (must include the `fa` and/or `cf`
#'   arms, which store the propensity scores).
#' @param ... unused.
#' @return A data frame with one row per available propensity vector: `arm`,
#'   `n`, `min`, `max`, and the percentages below `g_bound`, above `1 - g_bound`,
#'   and at either floor.
#' @export
overlap <- function(object, ...) UseMethod("overlap")

#' @rdname overlap
#' @export
overlap.svytmle <- function(object, ...) {
  g <- list(`Fully-Aware (single-fit)` = object$g_fa,
            `Fully-Aware-CF (out-of-fold)` = object$g_cf)
  g <- g[!vapply(g, is.null, logical(1))]
  if (!length(g))
    stop("no propensity scores stored; refit including the \"fa\" and/or ",
         "\"cf\" arms (overlap is a TMLE diagnostic).", call. = FALSE)
  b <- object$g_bound
  do.call(rbind, lapply(names(g), function(nm) {
    gg <- g[[nm]]
    data.frame(arm = nm, n = length(gg), min = min(gg), max = max(gg),
               pct_below = round(100 * mean(gg < b), 2),
               pct_above = round(100 * mean(gg > 1 - b), 2),
               pct_at_floor = round(100 * mean(gg < b | gg > 1 - b), 2),
               g_bound = b, stringsAsFactors = FALSE)
  }))
}
