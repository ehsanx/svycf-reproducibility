# =====================================================================
# learners.R -- survey-weight-aware learner support for nuisance_weights = "survey"
# (added 0.1.2). SuperLearner delivers observation weights to a learner only
# through its `obsWeights` argument, and several stock wrappers never use it --
# notably SuperLearner::SL.earth, which is in this package's default library. In
# survey mode such a learner would silently stay unweighted inside a weighted
# ensemble, so survey mode refuses them and SL.earth.w is provided instead.
# =====================================================================

# Stock SuperLearner wrappers (2.0-29) whose bodies never use obsWeights.
.NW_IGNORE <- c("SL.earth", "SL.randomForest", "SL.svm", "SL.ksvm", "SL.bartMachine",
                "SL.step", "SL.step.forward", "SL.step.interaction", "SL.stepAIC",
                "SL.ridge", "SL.knn", "SL.ipredbagg", "SL.lda", "SL.qda", "SL.logreg",
                "SL.leekasso", "SL.biglasso")
# Wrappers known to pass obsWeights to the underlying fit.
.NW_HONOUR <- c("SL.glm", "SL.glmnet", "SL.ranger", "SL.gam", "SL.xgboost", "SL.nnet",
                "SL.rpart", "SL.mean", "SL.bayesglm", "SL.speedglm", "SL.polymars", "SL.earth.w")

# Survey mode only: stop for learners known to ignore obsWeights, warn for unknown ones.
.check_nuisance_learners <- function(learners, nuisance_weights) {
  if (!identical(nuisance_weights, "survey")) return(invisible(TRUE))
  bad <- intersect(learners, .NW_IGNORE)
  if (length(bad))
    stop("nuisance_weights = \"survey\" needs learners that use the survey weights; ",
         paste(sQuote(bad), collapse = ", "), " ignore(s) SuperLearner's obsWeights ",
         "(use \"SL.earth.w\" in place of \"SL.earth\").", call. = FALSE)
  unk <- setdiff(learners, .NW_HONOUR)
  if (length(unk))
    warning("nuisance_weights = \"survey\": cannot confirm that ", paste(sQuote(unk), collapse = ", "),
            " use(s) SuperLearner's obsWeights; a learner that ignores them stays unweighted.",
            call. = FALSE)
  invisible(TRUE)
}

#' Survey-weight-aware MARS learner for SuperLearner
#'
#' A drop-in replacement for `SuperLearner::SL.earth` that passes SuperLearner's
#' observation weights (`obsWeights`) to [earth::earth()] (which also forwards
#' them to its GLM step for binomial outcomes). `SL.earth` ignores them, so
#' under `nuisance_weights = "survey"` it would silently stay unweighted; use
#' `"SL.earth.w"` instead. With equal weights it fits the same model as
#' `SL.earth`. Arguments and defaults are those of `SuperLearner::SL.earth`;
#' prediction uses SuperLearner's `predict.SL.earth`.
#'
#' @param Y,X,newX,family,obsWeights,id as for SuperLearner learner wrappers.
#' @param degree,penalty,nk,pmethod,nfold,ncross,minspan,endspan passed to
#'   [earth::earth()] (defaults as in `SuperLearner::SL.earth`).
#' @param ... ignored.
#' @return A SuperLearner learner result: `list(pred, fit)`, `fit` of class
#'   `"SL.earth"`.
#' @export
SL.earth.w <- function(Y, X, newX, family, obsWeights, id, degree = 2, penalty = 3,
                       nk = max(21, 2 * ncol(X) + 1), pmethod = "backward", nfold = 0,
                       ncross = 1, minspan = 0, endspan = 0, ...) {
  if (!requireNamespace("earth", quietly = TRUE))
    stop("SL.earth.w needs the 'earth' package.", call. = FALSE)
  args <- list(x = X, y = Y, weights = obsWeights, degree = degree, nk = nk, penalty = penalty,
               pmethod = pmethod, nfold = nfold, ncross = ncross, minspan = minspan, endspan = endspan)
  if (identical(family$family, "binomial")) args$glm <- list(family = stats::binomial)
  fit.earth <- do.call(earth::earth, args)
  pred <- stats::predict(fit.earth, newdata = newX, type = "response")
  fit <- list(object = fit.earth)
  class(fit) <- "SL.earth"
  list(pred = pred, fit = fit)
}
