# =====================================================================
# diagnostics.R — clustering design-effect (deff_clust) and ICC accessors
#
# Byte-faithful ports of the reference diagnostics
# (survey-tmle2/codes/diagnostics.R::deff_clust and dgp.R::icc_anova): the
# clustering-only design effect on the influence function (the quantity that
# drives coverage) and the one-way-ANOVA intra-cluster correlation.
# =====================================================================

# one-way ANOVA / method-of-moments ICC (continuous or 0/1 x)
.icc_anova <- function(x, cluster) {
  grp <- split(x, cluster)
  nj  <- vapply(grp, length, integer(1))
  M   <- length(grp); N <- length(x); gm <- mean(x)
  if (M < 2L) return(NA_real_)
  MSB <- sum(nj * (vapply(grp, mean, numeric(1)) - gm)^2) / (M - 1)
  MSW <- sum(vapply(grp, function(v) sum((v - mean(v))^2), numeric(1))) / max(1, (N - M))
  n0  <- (N - sum(nj^2) / N) / (M - 1)
  s2b <- (MSB - MSW) / n0
  max(0, s2b / (s2b + MSW))
}

# clustering-only DEFF on a supplied EIF: ratio of the clustered design SE to the
# i.i.d.-cluster SE of the SAME weighted Hajek mean of the SAME eif (the CV(w)^2
# weighting term divides out, isolating clustering+strata).
.deff_clust <- function(eif, strata, cluster, weight) {
  dat <- data.frame(eif = eif, strata = strata, cluster = cluster, weight = weight)
  d_full <- svydesign(ids = ~cluster, strata = ~strata, weights = ~weight, data = dat)
  d_iid  <- svydesign(ids = ~1, weights = ~weight, data = dat)
  se_full <- as.numeric(SE(svymean(~eif, d_full)))
  se_iid  <- as.numeric(SE(svymean(~eif, d_iid)))
  list(deff_clust = (se_full / se_iid)^2, se_full = se_full, se_iid = se_iid,
       icc_eif = .icc_anova(eif, cluster))
}

#' Clustering design effect and ICC of the influence function
#'
#' Reports the clustering-only design effect (`deff_clust`) and the intra-cluster
#' correlation (`icc_eif`) of a fitted arm's per-unit influence function -- the
#' quantities that drive the design-based variance and coverage. `deff_clust` is
#' the squared ratio of the clustered design SE to the i.i.d.-cluster SE of the
#' same weighted mean of the influence function.
#'
#' @param object a fitted [svytmle()] object (the requested `arm` must have run,
#'   so its per-arm components are stored).
#' @param arm which arm's influence function to use: `"cf"` (default) or `"fa"`.
#' @param ... unused.
#' @return A one-row data frame: `arm`, `deff_clust`, `icc_eif`, and the
#'   clustered/i.i.d. SEs.
#' @export
deff <- function(object, ...) UseMethod("deff")

#' @rdname deff
#' @export
deff.svytmle <- function(object, arm = c("cf", "fa"), ...) {
  if (is.null(object$arm_components))
    stop("this fit has no stored per-arm components; refit with svytmle().",
         call. = FALSE)
  arm   <- match.arg(arm)
  label <- c(cf = "Fully-Aware-CF", fa = "Fully-Aware")[[arm]]
  comp  <- object$arm_components[[label]]
  if (is.null(comp))
    stop("the '", arm, "' arm is not in this fit; refit including it.", call. = FALSE)
  eif  <- comp$eif1 - comp$eif0                      # ATE influence function
  dc   <- object$design_cols
  rows <- if (is.null(object$inpop)) seq_along(dc$strata) else which(object$inpop)
  d <- .deff_clust(eif, dc$strata[rows], dc$cluster[rows], dc$weight[rows])
  data.frame(arm = label, deff_clust = d$deff_clust, icc_eif = d$icc_eif,
             se_clustered = d$se_full, se_iid = d$se_iid, stringsAsFactors = FALSE)
}
