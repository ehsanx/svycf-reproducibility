#' svytmle: survey-weighted cross-fitted TMLE with design-based variance
#'
#' Cross-fitted, survey-weighted targeted maximum likelihood estimation of
#' the population average treatment effect from complex survey data, with a
#' design-based (Taylor-series linearization) variance treating the
#' first-stage sampling unit (PSU) as the independent unit. See [svytmle()]
#' for the estimator and `vignette(package = "svytmle")` for the NHANES and
#' simulation tutorials.
#'
#' Not to be confused with the `survtmle` package (TMLE for *survival*
#' outcomes) or the `tmle` package (iid-data TMLE, used internally here for
#' the targeting step).
#'
#' @keywords internal
#' @import SuperLearner
#' @importFrom survey svydesign svymean SE degf as.svrepdesign withReplicates
#' @importFrom tmle tmle
#' @importFrom stats ave binomial gaussian model.matrix plogis predict qt rbinom
#'   rnorm sd uniroot var weighted.mean weights
#' @importFrom utils globalVariables
"_PACKAGE"

# non-standard evaluation used inside the primary engine (.se_des subsets
# the rebuilt design on the .inpop indicator column)
utils::globalVariables(".inpop")
