# =====================================================================
# estimands-rr-or.R  —  RR / OR (and continuous ratio-of-means) by the
# delta method on the per-arm survey-TMLE influence functions. Tier-1
# estimand feature; mirrors the analysis-repo derivation (Web Appendix
# RR/OR corollary). Non-breaking: a pure post-processor over the per-arm
# components the engine exposes in diagnostics$arms.
# =====================================================================

# Sigma = design covariance of (psi1_hat, psi0_hat) from the per-arm EIFs.
# Mirrors .se_des: simulation path (inpop = NULL) builds the design on the
# supplied rows; domain path embeds the EIFs into full-length vectors and
# subset()s the FULL design (proper sub-population variance).
.cov2_des <- function(eif1, eif0, strata, cluster, weight,
                      clustered = TRUE, nest = FALSE, inpop = NULL) {
  if (is.null(inpop)) {
    dat <- data.frame(e1 = eif1, e0 = eif0, strata = strata, cluster = cluster, weight = weight)
    des <- if (clustered)
      survey::svydesign(ids = ~cluster, strata = ~strata, weights = ~weight, data = dat)
    else
      survey::svydesign(ids = ~1, weights = ~weight, data = dat)
  } else {
    e1f <- numeric(length(inpop)); e1f[inpop] <- eif1
    e0f <- numeric(length(inpop)); e0f[inpop] <- eif0
    dat <- data.frame(e1 = e1f, e0 = e0f, strata = strata, cluster = cluster,
                      weight = weight, .inpop = inpop)
    des <- if (clustered)
      survey::svydesign(ids = ~cluster, strata = ~strata, weights = ~weight, data = dat, nest = nest)
    else
      survey::svydesign(ids = ~1, weights = ~weight, data = dat)
    des <- subset(des, .inpop)
  }
  m <- survey::svymean(~e1 + e0, des)
  list(Sigma = stats::vcov(m), df = survey::degf(des))
}

#' Risk ratio, odds ratio, and continuous ratio-of-means by the delta method
#'
#' Post-processes the per-arm targeted means and influence functions returned by
#' the survey-weighted cross-fitted TMLE engine (exposed in \code{diagnostics$arms})
#' into design-based delta-method Wald intervals for the risk ratio (RR), odds
#' ratio (OR), or, for a bounded continuous outcome, the ratio of means. The
#' per-arm influence functions give a joint design central limit theorem for
#' \eqn{(\hat\psi_1, \hat\psi_0)}; any smooth contrast is then asymptotically
#' normal with design variance \eqn{\nabla\kappa^\top \widehat\Sigma_w \nabla\kappa},
#' where \eqn{\widehat\Sigma_w} is the Equation-(8) design covariance read as a
#' bilinear form (see the package's Web Appendix corollary).
#'
#' @param psi1,psi0 per-arm targeted means \eqn{\hat\psi_1, \hat\psi_0}.
#' @param eif1,eif0 per-unit per-arm influence functions \eqn{D_1, D_0}.
#' @param strata,cluster,weight survey design columns (same length as the EIFs on
#'   the simulation path; full length together with \code{inpop} on the domain path).
#' @param clustered logical; clustered design SE (\code{TRUE}) or weighted no-cluster.
#' @param level confidence level for the Wald interval.
#' @param binary \code{TRUE} returns RR and OR for a mean in \eqn{[0,1]};
#'   \code{FALSE} returns the ratio of (positive) means only (continuous outcome).
#' @param eps clamp keeping the means strictly inside \eqn{(0,1)} for stable
#'   gradients (binary case).
#' @param nest passed to \code{survey::svydesign} (\code{TRUE} when PSU ids repeat
#'   across strata, as with NHANES \code{SDMVPSU}).
#' @param inpop optional logical domain selector; the design is built on the full
#'   sample and \code{subset()}-ed to the domain, matching the engine's variance.
#' @return A \code{data.frame}, one row per estimand, with the point estimate
#'   (\code{est}), the log-scale standard error (\code{se_log}), the t-df Wald
#'   interval (\code{lo}, \code{hi}), the design df, and the per-arm means.
#' @export
delta_rr_or <- function(psi1, psi0, eif1, eif0, strata, cluster, weight,
                        clustered = TRUE, level = 0.95, binary = TRUE,
                        eps = 1e-6, nest = FALSE, inpop = NULL) {
  cc   <- .cov2_des(eif1, eif0, strata, cluster, weight,
                    clustered = clustered, nest = nest, inpop = inpop)
  Sig  <- cc$Sigma; df <- cc$df
  crit <- stats::qt(1 - (1 - level) / 2, max(1, df))
  mk <- function(estimand, log_est, grad) {
    v  <- as.numeric(crossprod(grad, Sig %*% grad))
    se <- sqrt(max(v, 0))
    data.frame(estimand = estimand, est = exp(log_est), log_est = log_est,
               se_log = se, lo = exp(log_est - crit * se), hi = exp(log_est + crit * se),
               df = df, psi1 = psi1, psi0 = psi0, row.names = NULL)
  }
  if (binary) {
    p1 <- min(max(psi1, eps), 1 - eps); p0 <- min(max(psi0, eps), 1 - eps)
    rbind(
      mk("RR", log(p1) - log(p0),                     c(1 / p1, -1 / p0)),
      mk("OR", stats::qlogis(p1) - stats::qlogis(p0), c(1 / (p1 * (1 - p1)), -1 / (p0 * (1 - p0))))
    )
  } else {
    if (psi1 <= 0 || psi0 <= 0)
      stop("ratio-of-means RR needs positive per-arm means; got psi1=", psi1, " psi0=", psi0)
    mk("RR", log(psi1) - log(psi0), c(1 / psi1, -1 / psi0))
  }
}

# ---------------------------------------------------------------------------
# Relative effects FROM A FIT: riskratio() / oddsratio() convenience generics.
# Post-process the per-arm components a svytmle fit stores in $arm_components
# (engine's diagnostics$arms) through delta_rr_or(), reconstructing the exact
# variance path (simulation vs domain) the engine used.
# ---------------------------------------------------------------------------
.ratio_estimand <- function(object, arm, level, which) {
  if (is.null(object$arm_components))
    stop("this fit has no stored per-arm components; refit with svytmle() ",
         "(the components are stored automatically for the fa/cf arms).",
         call. = FALSE)
  arm   <- match.arg(arm, c("cf", "fa"))
  label <- c(cf = "Fully-Aware-CF", fa = "Fully-Aware")[[arm]]
  comp  <- object$arm_components[[label]]
  if (is.null(comp))
    stop("the '", arm, "' arm's per-arm components are not in this fit; refit ",
         "including that arm (arms = \"", arm, "\" or arms = \"all\").",
         call. = FALSE)
  if (is.null(level)) level <- object$level
  dc     <- object$design_cols
  binary <- !identical(object$family, "gaussian")
  res <- delta_rr_or(comp$psi1, comp$psi0, comp$eif1, comp$eif0,
                     strata = dc$strata, cluster = dc$cluster, weight = dc$weight,
                     clustered = TRUE, level = level, binary = binary,
                     nest = isTRUE(object$nest), inpop = object$inpop)
  out <- res[res$estimand == which, , drop = FALSE]
  if (!nrow(out))
    stop(which, " is not available for outcome family '", object$family, "'.",
         call. = FALSE)
  rownames(out) <- NULL
  attr(out, "arm") <- label
  out
}

#' Risk ratio / odds ratio from a fitted survey-TMLE
#'
#' Compute the population risk ratio (`riskratio()`) or odds ratio
#' (`oddsratio()`) and its design-based delta-method confidence interval from a
#' fitted [svytmle()] object, using the per-arm targeted means and influence
#' functions the fit stores. For a continuous outcome (`family = "gaussian"`)
#' `riskratio()` returns the ratio of means; `oddsratio()` is binary-only.
#'
#' @param object a fitted [svytmle()] object.
#' @param arm which arm's per-arm components to use: `"cf"` (default, the
#'   primary cross-fitted arm) or `"fa"` (single-fit). The requested arm must
#'   have been run (it is for `arms = "cf"`, `"fa"`, or `"all"`).
#' @param level confidence level; defaults to the fit's level. Re-leveling needs
#'   no refit (the design df is fixed).
#' @param ... unused.
#' @return A one-row data frame with the estimand, point estimate (`est`), the
#'   log-scale SE (`se_log`), the t-df Wald interval (`lo`, `hi`), the design df,
#'   and the per-arm means; the source arm is in `attr(., "arm")`.
#' @seealso [svytmle()], [delta_rr_or()].
#' @examples
#' \donttest{
#' pop <- make_population("standard", "simple", truth_M = 1e4L)
#' des <- survey::svydesign(ids = ~cluster, strata = ~strata, weights = ~weight,
#'                          data = draw_sample(pop, sample_seed = 7L))
#' set.seed(1)
#' fit <- svytmle(des, "Y", "A", c("L1", "L2", "L3", "L4"), learners = "SL.glm")
#' riskratio(fit)
#' oddsratio(fit)
#' }
#' @export
riskratio <- function(object, ...) UseMethod("riskratio")

#' @rdname riskratio
#' @export
oddsratio <- function(object, ...) UseMethod("oddsratio")

#' @rdname riskratio
#' @export
riskratio.svytmle <- function(object, arm = c("cf", "fa"), level = NULL, ...) {
  .ratio_estimand(object, arm, level, which = "RR")
}

#' @rdname riskratio
#' @export
oddsratio.svytmle <- function(object, arm = c("cf", "fa"), level = NULL, ...) {
  if (identical(object$family, "gaussian"))
    stop("oddsratio() is defined for a binary outcome (family = \"binomial\"); ",
         "for a continuous outcome use riskratio() (ratio of means).",
         call. = FALSE)
  .ratio_estimand(object, arm, level, which = "OR")
}
