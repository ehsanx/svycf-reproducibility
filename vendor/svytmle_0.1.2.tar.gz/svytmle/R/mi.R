# =====================================================================
# mi.R — multiple-imputation (Rubin's rules) pooling for svytmle()
#
# svytmle_mi() runs the primary estimator on each of M completed-data survey
# designs and pools the per-arm point estimates + design-based SEs by Rubin's
# rules with the Barnard-Rubin (1999) small-sample df correction on the survey
# design df. This is the headline NHANES Table-2 path. The pooling logic is a
# byte-faithful port of survey-tmle2/Nhanes/arc_runs/R06_mi/mi_helpers.R
# (rubin_pool); it matches mice::pool(). No dependency on mice: imputation is
# the user's job (build the M designs from mice::complete(mids, "all")).
# =====================================================================

# Rubin (1987) / Barnard-Rubin (1999) pooling of ONE arm across M imputations.
# b, se: length-M per-imputation estimate + SE; df_complete: the (shared) design
# df. Returns pooled estimate, total-variance SE, Barnard-Rubin df, riv, fmi.
.rubin_pool <- function(b, se, df_complete) {
  M    <- length(b)
  qbar <- mean(b)                       # pooled point estimate
  Ubar <- mean(se^2)                    # within-imputation variance
  B    <- if (M > 1L) stats::var(b) else 0   # between-imputation variance
  Tvar <- Ubar + (1 + 1 / M) * B        # total variance
  se_p <- sqrt(Tvar)
  if (M > 1L && B > 0) {
    riv    <- (1 + 1 / M) * B / Ubar               # relative increase in variance
    df_old <- (M - 1) * (1 + 1 / riv)^2            # classic Rubin (1987) df
    lambda <- (1 + 1 / M) * B / Tvar
    df_obs <- if (is.finite(df_complete) && df_complete > 0)
                (df_complete + 1) / (df_complete + 3) * df_complete * (1 - lambda)
              else Inf
    df_br  <- if (is.finite(df_obs)) df_old * df_obs / (df_old + df_obs) else df_old
    fmi    <- (riv + 2 / (df_br + 3)) / (riv + 1)
  } else {
    riv <- 0; df_br <- df_complete; fmi <- 0
  }
  list(b = qbar, se = se_p, df = df_br, Ubar = Ubar, B = B, Tvar = Tvar,
       riv = riv, fmi = fmi, M = M)
}

#' Multiple-imputation (Rubin) pooling of survey-weighted TMLE
#'
#' Runs [svytmle()] on each of `M` completed-data survey designs (one per
#' imputation) and pools the per-arm point estimates and design-based standard
#' errors by Rubin's rules, with the Barnard-Rubin (1999) small-sample degrees-
#' of-freedom correction anchored on the survey design df (number of PSUs minus
#' number of strata). It matches `mice::pool()`, and using the *survey* df (not
#' `n - 1`) for the Barnard-Rubin correction is the key footgun this wrapper
#' removes.
#'
#' Imputation itself is the user's responsibility: build the list of completed
#' designs from, e.g., `mice::complete(mids, "all")`, wrapping each completed
#' data frame in a [survey::svydesign()] with the same design formulas.
#'
#' @param designs a *list* of [survey::svydesign()] objects, one per imputation
#'   (length `M >= 2`), each built from a completed data set with the same design.
#' @param outcome,treatment,covariates,learners,subset,arms,family,cf_folds,inner_cv_folds,g_bound,level,nuisance_weights
#'   passed through to [svytmle()] for each imputation (see [svytmle()]).
#' @param seed optional integer base seed. When supplied, imputation `k` is run
#'   under `set.seed(seed + 1000 * k)` so the cross-fit/SuperLearner splits are
#'   reproducible (and distinct across imputations, so split variability is
#'   averaged over). When `NULL` (default) the ambient RNG stream is used.
#'
#' @return An object of class `c("svytmle_mi", "svytmle")`: `results` is the
#'   pooled per-arm data frame (`b`, `se`, Barnard-Rubin `df`, `lcl`/`ucl`,
#'   `fmi`, `riv`, `M`, and the within/between decomposition); `per_imputation`
#'   holds the M per-arm rows. `coef()`, `confint()`, `as.data.frame()`, `tidy()`
#'   work as for [svytmle()], and [riskratio()] / [oddsratio()] return the
#'   Rubin-pooled relative effects (pooled on the log scale).
#'
#' @seealso [svytmle()]; [riskratio()] / [oddsratio()] for pooled relative
#'   effects; the package vignettes for the end-to-end NHANES MI workflow.
#' @examples
#' \donttest{
#' pop <- make_population("standard", "simple", truth_M = 1e4L)
#' # stand-in for an mice::complete(mids, "all") list: M resampled designs
#' designs <- lapply(1:5, function(k)
#'   survey::svydesign(ids = ~cluster, strata = ~strata, weights = ~weight,
#'                     data = draw_sample(pop, sample_seed = 100L + k)))
#' fit <- svytmle_mi(designs, "Y", "A", c("L1", "L2", "L3", "L4"),
#'                   learners = "SL.glm", seed = 1L)
#' fit
#' }
#' @export
svytmle_mi <- function(designs, outcome, treatment, covariates,
                       learners = c("SL.glm", "SL.earth", "SL.glmnet"),
                       subset = NULL, arms = "cf",
                       family = c("binomial", "gaussian"),
                       cf_folds = 5L, inner_cv_folds = 5L, g_bound = 0.05,
                       level = 0.95, seed = NULL,
                       nuisance_weights = c("unweighted", "survey")) {
  family <- match.arg(family)
  nuisance_weights <- match.arg(nuisance_weights)
  .check_nuisance_learners(learners, nuisance_weights)     # fail before the first imputation
  if (!is.list(designs) || inherits(designs, "survey.design"))
    stop("`designs` must be a LIST of survey.design objects (one per ",
         "imputation), e.g. lapply(mice::complete(mids, \"all\"), function(d) ",
         "survey::svydesign(ids = ~psu, strata = ~stratum, weights = ~w, ",
         "data = d, nest = TRUE)).", call. = FALSE)
  M <- length(designs)
  if (M < 2L)
    stop("`designs` must contain at least 2 imputed designs for Rubin pooling ",
         "(got ", M, "). For a single design use svytmle().", call. = FALSE)
  for (k in seq_len(M))
    if (!inherits(designs[[k]], "survey.design"))
      stop("designs[[", k, "]] is not a survey.design object.", call. = FALSE)
  if (!is.null(seed) && (!is.numeric(seed) || length(seed) != 1))
    stop("`seed` must be NULL or a single number.", call. = FALSE)

  per_imp    <- vector("list", M)
  ratio_rows <- vector("list", M)
  for (k in seq_len(M)) {
    if (!is.null(seed)) set.seed(seed + 1000L * k)
    fk <- svytmle(designs[[k]], outcome = outcome, treatment = treatment,
                  covariates = covariates, learners = learners, subset = subset,
                  arms = arms, family = family, cf_folds = cf_folds,
                  inner_cv_folds = inner_cv_folds, g_bound = g_bound, level = level,
                  nuisance_weights = nuisance_weights)
    rk <- fk$results[, c("method", "b", "se", "df")]
    rk$imp <- k
    per_imp[[k]] <- rk
    # per-imputation relative effects on the LOG scale (for the fa/cf arms whose
    # per-arm components are stored), so riskratio()/oddsratio() can Rubin-pool them.
    if (!is.null(fk$arm_components) && length(fk$arm_components)) {
      dc   <- fk$design_cols
      biny <- !identical(family, "gaussian")
      ratio_rows[[k]] <- do.call(rbind, lapply(names(fk$arm_components), function(lab) {
        comp <- fk$arm_components[[lab]]
        rd <- delta_rr_or(comp$psi1, comp$psi0, comp$eif1, comp$eif0,
                          strata = dc$strata, cluster = dc$cluster, weight = dc$weight,
                          clustered = TRUE, level = level, binary = biny,
                          nest = isTRUE(fk$nest), inpop = fk$inpop)
        rd$arm <- lab; rd$imp <- k; rd
      }))
    }
  }
  per_imp_df    <- do.call(rbind, per_imp)
  per_imp_ratio <- if (length(Filter(Negate(is.null), ratio_rows)))
    do.call(rbind, ratio_rows) else NULL

  methods <- unique(per_imp_df$method)
  pooled <- do.call(rbind, lapply(methods, function(mth) {
    s  <- per_imp_df[per_imp_df$method == mth, ]
    rp <- .rubin_pool(s$b, s$se, df_complete = s$df[1])   # all M share the design df
    data.frame(method = mth, b = rp$b, se = rp$se, df = rp$df,
               b_imp_sd = stats::sd(s$b), within_se = sqrt(rp$Ubar),
               between_sd = sqrt(rp$B), riv = rp$riv, fmi = rp$fmi, M = M,
               stringsAsFactors = FALSE)
  }))
  crit <- qt(1 - (1 - level) / 2, pmax(1, pooled$df))
  pooled$lcl <- pooled$b - crit * pooled$se
  pooled$ucl <- pooled$b + crit * pooled$se
  ord <- c("Fully-Aware", "Partially-Aware", "Non-Aware", "Fully-Aware-CV",
           "Fully-Aware-CF", "AIPW-SF", "AIPW-CV", "AIPW-CF")
  pooled <- pooled[order(match(pooled$method, ord)), ]
  rownames(pooled) <- NULL

  structure(list(
    results        = pooled,
    per_imputation = per_imp_df,
    per_imputation_ratio = per_imp_ratio,
    M              = M,
    family         = family,
    estimator      = "tmle",
    level          = level,
    g_bound        = g_bound,
    cf_folds       = cf_folds,
    nuisance_weights = nuisance_weights,
    learners       = learners,
    arms           = arms,
    outcome        = outcome,
    treatment      = treatment,
    covariates     = if (inherits(covariates, "formula")) all.vars(covariates) else covariates,
    call           = match.call()
  ), class = c("svytmle_mi", "svytmle"))
}

# Rubin-pool the per-imputation relative effects on the log scale, then exponentiate.
.pool_ratio <- function(object, arm, level, which) {
  pir <- object$per_imputation_ratio
  if (is.null(pir))
    stop("no per-imputation relative effects are stored; refit svytmle_mi() with ",
         "the 'cf' and/or 'fa' arm.", call. = FALSE)
  arm   <- match.arg(arm, c("cf", "fa"))
  label <- c(cf = "Fully-Aware-CF", fa = "Fully-Aware")[[arm]]
  s <- pir[pir$arm == label & pir$estimand == which, , drop = FALSE]
  if (!nrow(s))
    stop(which, " is not available for arm '", arm, "' / family '", object$family,
         "'.", call. = FALSE)
  if (is.null(level)) level <- object$level
  rp   <- .rubin_pool(s$log_est, s$se_log, df_complete = s$df[1])  # pool on LOG scale
  crit <- qt(1 - (1 - level) / 2, max(1, rp$df))
  data.frame(estimand = which, arm = label, est = exp(rp$b),
             log_est = rp$b, se_log = rp$se,
             lo = exp(rp$b - crit * rp$se), hi = exp(rp$b + crit * rp$se),
             df = rp$df, fmi = rp$fmi, M = rp$M, row.names = NULL)
}

#' Rubin-pooled risk ratio / odds ratio from multiply-imputed survey-TMLE
#'
#' Pools the per-imputation log-risk-ratio (or log-odds-ratio, or log-ratio-of-
#' means for a continuous outcome) across the imputations of a [svytmle_mi()] fit
#' by Rubin's rules with the Barnard-Rubin df, then exponentiates. The requested
#' `arm` must have been run in `svytmle_mi()` (default `arms = "cf"` stores the
#' cross-fit components).
#'
#' @param object a [svytmle_mi()] object.
#' @param arm `"cf"` (default) or `"fa"`.
#' @param level confidence level; defaults to the fit's level.
#' @param ... unused.
#' @return A one-row data frame: estimand, arm, point estimate (`est`), pooled
#'   log-scale SE, the Wald interval (`lo`, `hi`), Barnard-Rubin `df`, `fmi`, `M`.
#' @name riskratio.svytmle_mi
#' @export
riskratio.svytmle_mi <- function(object, arm = c("cf", "fa"), level = NULL, ...) {
  .pool_ratio(object, arm, level, which = "RR")
}

#' @rdname riskratio.svytmle_mi
#' @export
oddsratio.svytmle_mi <- function(object, arm = c("cf", "fa"), level = NULL, ...) {
  if (identical(object$family, "gaussian"))
    stop("oddsratio() is defined for a binary outcome; for a continuous outcome ",
         "use riskratio() (ratio of means).", call. = FALSE)
  .pool_ratio(object, arm, level, which = "OR")
}

#' @export
print.svytmle_mi <- function(x, digits = 4, ...) {
  rr  <- x$results
  fam <- if (identical(x$family, "gaussian")) "mean difference" else "risk difference"
  cat(sprintf(
    "svytmle_mi: MI-pooled survey-weighted TMLE (%s); m = %d imputations (Rubin/Barnard-Rubin)\n  outcome '%s' ~ treatment '%s' | %d adjustment covariate(s); learners: %s\n\n",
    fam, x$M, x$outcome, x$treatment, length(x$covariates),
    paste0(paste(x$learners, collapse = " + "),
           if (identical(x$nuisance_weights, "survey") && any(rr$method %in% c("Fully-Aware-CF", "Fully-Aware-CV")))
             " (CF/CV nuisances survey-weighted)" else "")))
  out <- rr[, c("method", "b", "se", "df", "lcl", "ucl", "fmi")]
  num <- vapply(out, is.numeric, logical(1)); out[num] <- lapply(out[num], round, digits)
  print(out, row.names = FALSE)
  i   <- .primary_row(x)
  lab <- if ("Fully-Aware-CF" %in% rr$method)
    "Primary (cross-fitted) MI estimate" else "MI estimate"
  cat(sprintf("\n%s: %s = %.*f, %g%% CI [%.*f, %.*f] (t, df = %.1f; fmi = %.3f)\n",
              lab, rr$method[i], digits, rr$b[i], 100 * x$level,
              digits, rr$lcl[i], digits, rr$ucl[i], rr$df[i], rr$fmi[i]))
  invisible(x)
}
