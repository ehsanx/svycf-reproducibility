# =====================================================================
# svytmle.R — the user-facing wrapper around the primary engine
#
# Translates a survey::svydesign + variable spec into the engine's data
# contract EXACTLY as the as-run NHANES driver did
# (survey-tmle2/Nhanes/R/03_run_estimators.R): recover the raw design
# columns, one-hot encode the domain covariates via model.matrix, attach
# the encoded columns NA-padded to the full frame, then call
# run_estimators() with nest = TRUE and the domain indicator. No random
# numbers are consumed between the caller's set.seed() and the engine.
# =====================================================================

# known SuperLearner wrapper -> backing package map (for friendly errors)
.learner_backing <- c(SL.earth = "earth", SL.glmnet = "glmnet", SL.gam = "gam",
                      SL.ranger = "ranger", SL.xgboost = "xgboost",
                      SL.nnet = "nnet", SL.rpart = "rpart",
                      SL.randomForest = "randomForest", SL.ksvm = "kernlab",
                      SL.svm = "e1071", SL.bartMachine = "bartMachine")

.check_learners <- function(learners) {
  if (!is.character(learners) || length(learners) < 1)
    stop("`learners` must be a character vector of SuperLearner wrapper names.",
         call. = FALSE)
  need <- unique(.learner_backing[learners])
  need <- need[!is.na(need)]
  if (length(need)) {
    have <- vapply(need, requireNamespace, logical(1), quietly = TRUE)
    if (any(!have))
      stop("the requested learner library needs package(s) ",
           paste(sQuote(need[!have]), collapse = ", "),
           " -- install them, or pass a different `learners` library ",
           "(e.g. learners = \"SL.glm\").", call. = FALSE)
  }
  invisible(TRUE)
}

# ---------------------------------------------------------------------------
# .prepare_engine_input(): shared design->engine-frame translation used by both
# svytmle() and svyaipw(). Recovers the raw design columns, validates the spec,
# routes nested-id / domain analyses, coerces the outcome (family-aware) and
# treatment to the engine's contract, and one-hot encodes the covariates EXACTLY
# as the reference NHANES driver did. Consumes NO random numbers (the contract:
# nothing between the caller's set.seed() and the engine). Extracted verbatim
# from svytmle()'s former body (the primary cf path is unchanged; guarded by
# the equivalence tests) with the single addition of the gaussian outcome branch.
# ---------------------------------------------------------------------------
.prepare_engine_input <- function(design, outcome, treatment, covariates,
                                  subset = NULL, family = "binomial",
                                  allow_replicate = FALSE) {
  is_rep <- inherits(design, "svyrep.design")
  .check_design(design, allow_replicate = allow_replicate)
  vars <- design$variables
  n_full <- nrow(vars)
  # A replicate-weight design carries no PSU/strata for the engine's PSU-level
  # cross-fitting: use the full-sample weights and an observation-level fold
  # structure (strata = 1, each row its own "PSU" -> random V-fold cross-fitting,
  # the i.i.d. DML default). The design is still captured through its replicate
  # weights at the variance step (.se_replicate). For a linearization design the
  # primary PSU-level structure is recovered as usual.
  ext  <- if (is_rep)
    list(strata = rep(1L, n_full), cluster = seq_len(n_full),
         weight = as.numeric(stats::weights(design, type = "sampling")),
         source = "svrep")
  else .design_extract(design)

  if (inherits(covariates, "formula")) covariates <- all.vars(covariates)
  if (!is.character(covariates) || length(covariates) < 1)
    stop("`covariates` must be a character vector of column names or a ",
         "one-sided formula.", call. = FALSE)
  for (nm in c(outcome, treatment, covariates))
    if (!nm %in% names(vars))
      stop("column '", nm, "' not found in the design variables.", call. = FALSE)
  if (outcome %in% covariates || treatment %in% covariates)
    stop("`covariates` must not contain the outcome or treatment column.",
         call. = FALSE)
  if (identical(outcome, treatment))
    stop("`outcome` and `treatment` must be different columns.", call. = FALSE)
  if (anyDuplicated(covariates))
    stop("`covariates` contains duplicated name(s): ",
         paste(sQuote(unique(covariates[duplicated(covariates)])), collapse = ", "),
         call. = FALSE)

  # every stratum must contribute >= 2 first-stage PSUs (the design df and the
  # linearization variance need them; survey would otherwise error only after
  # the expensive nuisance fits, or silently under options(survey.lonely.psu=))
  psu_key <- unique(data.frame(s = ext$strata, c = ext$cluster,
                               stringsAsFactors = FALSE))
  per_str <- table(psu_key$s)
  if (any(per_str < 2L))
    stop("stratum/strata ", paste(sQuote(names(per_str)[per_str < 2L]),
                                  collapse = ", "),
         " contribute only one PSU; the primary design-based variance needs ",
         ">= 2 PSUs per stratum. Collapse such strata before building the ",
         "svydesign.", call. = FALSE)

  inpop <- .resolve_subset(subset, vars)
  # nested (repeating-across-strata) PSU ids cannot ride the engine's
  # whole-sample path; route them through the domain path with an all-TRUE
  # indicator -- numerically identical for the fa/pa/na/cf arms.
  if (is.null(inpop) && anyDuplicated(psu_key$c))
    inpop <- rep(TRUE, n_full)
  rows  <- if (is.null(inpop)) seq_len(n_full) else which(inpop)

  Yv <- if (identical(family, "gaussian"))
          .num_outcome(vars[[outcome]], outcome, rows)
        else .binary01(vars[[outcome]], outcome, rows)
  Av <- .binary01(vars[[treatment]], treatment, rows)

  # ---- assemble the engine frame exactly as the reference NHANES driver ----
  obs <- vars
  covdf <- droplevels(obs[rows, covariates, drop = FALSE])
  if (anyNA(covdf)) {
    bad <- names(covdf)[vapply(covdf, anyNA, logical(1))]
    stop("covariate(s) ", paste(sQuote(bad), collapse = ", "), " have missing ",
         "values on the analytic domain. svytmle() does not impute; impute ",
         "first (see the NHANES vignettes for a multiple-imputation workflow).",
         call. = FALSE)
  }
  mm <- model.matrix(~ ., data = covdf)[, -1, drop = FALSE]
  if (ncol(mm) < 2)
    stop("`covariates` encode to ", ncol(mm), " design-matrix column(s); the ",
         "engine needs at least two (the paper's analyses all ",
         "adjust for several covariates). Add covariates.", call. = FALSE)
  stopifnot(nrow(mm) == length(rows))
  wnames <- make.names(colnames(mm), unique = TRUE); colnames(mm) <- wnames
  clash <- intersect(wnames, c("Y", "A", "strata", "cluster", "weight"))
  if (length(clash))
    stop("encoded covariate name(s) ", paste(sQuote(clash), collapse = ", "),
         " collide with the engine's reserved columns; rename the covariate(s).",
         call. = FALSE)
  for (j in seq_along(wnames)) {
    obs[[wnames[j]]] <- NA_real_
    obs[[wnames[j]]][rows] <- mm[, j]
  }
  obs$Y <- Yv
  obs$A <- Av
  obs$strata  <- ext$strata
  obs$cluster <- ext$cluster
  obs$weight  <- ext$weight

  list(ext = ext, inpop = inpop, rows = rows, obs = obs, wnames = wnames,
       n_full = n_full, covariates = covariates)
}

#' Survey-weighted cross-fitted TMLE for the population ATE
#'
#' Estimates the population average treatment effect (risk difference) from
#' complex survey data, with a design-based (Taylor-series linearization)
#' variance that treats the first-stage sampling unit (PSU) as the
#' independent unit. The default `arms = "cf"` is the recommended cross-fitted
#' estimator; `arms = "all"` adds four design-awareness comparison arms.
#'
#' @details
#' The cross-fitted estimator is numerically validated against the published
#' analysis of Karim (2026): at a fixed seed it reproduces that paper's results
#' bit-for-bit, as checked by the package's equivalence tests and the scripts in
#' `system.file("equivalence", package = "svytmle")`.
#'
#' The primary estimator (`"cf"`, *Fully-Aware-CF*) is, exactly:
#'
#' * **PSU-level cross-fitting.** Folds are whole PSUs nested within strata.
#'   Within each stratum the balanced cyclic fold-size pattern is assigned to
#'   PSUs in random order (a stratum with 3 PSUs and `V = 2` splits 2--1;
#'   which PSU lands in which fold is randomized; the total size imbalance is
#'   bounded, `D = o(sqrt(m))`). `V` is reduced to the minimum number of PSUs
#'   per stratum so every training fold spans every stratum (every stratum
#'   must contribute at least 2 PSUs -- enforced on the full design; in a
#'   domain analysis a stratum with a single domain PSU is absent from one
#'   training fold, which `nuisance_weights = "survey"` warns about); with 2
#'   PSUs per stratum this is leave-one-PSU-per-stratum-out.
#' * **Unweighted out-of-fold nuisances (default).** The outcome regression and
#'   the propensity score are fit on training folds WITHOUT survey weights
#'   (consistent under sampling ignorability, S independent of (A, Y) given
#'   the covariates; this also avoids weighted-fit separation), and predicted
#'   on the held-out fold. When sampling may be informative given the
#'   covariates (for example stage-2 selection probabilities that depend on
#'   facility caseload), set `nuisance_weights = "survey"`: the fold-specific
#'   fits then use the survey weights, rescaled within each training fold by
#'   `m_h / m_train,h` (the stratum's PSU count over its PSUs in the training
#'   fold) and normalised to mean 1, so each training fold represents the
#'   population (provided every stratum has at least 2 analysed PSUs). Every
#'   learner must use SuperLearner's `obsWeights`: survey mode refuses
#'   wrappers that ignore them (e.g. `SL.earth`; use [SL.earth.w]). Targeting, the influence function and the design variance
#'   are unchanged. The default reproduces the published analysis
#'   bit-for-bit.
#' * **Propensity truncation.** Out-of-fold propensity predictions are
#'   truncated to `[g_bound, 1 - g_bound]` (default `[0.05, 0.95]`). (The
#'   `"cv"` comparison arm's full-sample propensity predictions receive the
#'   same truncation; the single-fit arms use the `tmle` engine's internal
#'   bounds.)
#' * **Weighted targeting.** In the default mode, survey weights enter ONLY at
#'   the targeting and variance steps. Targeting uses the `tmle` engine's arm-specific
#'   two-parameter logistic fluctuation (epsilon0, epsilon1) on the clever
#'   covariates (H0W, H1W), with the survey weights as observation weights.
#' * **Design-based variance.** The per-unit efficient influence function is
#'   reconstructed UNWEIGHTED from the targeted `Qstar` and `g1W` (avoiding
#'   the double-weighting that inflates the SE if the weight-incorporated
#'   `IC.ATE` is fed to `svymean`), then its design variance is computed by
#'   `survey::svymean` on the stratified-cluster design. Confidence
#'   intervals use a t reference with the design degrees of freedom
#'   (number of PSUs minus number of strata).
#' * **Domain (sub-population) analyses.** With `subset`, nuisances and
#'   targeting are fit on the domain, while the variance is computed on the
#'   FULL design then subset (subset the design, not the data), so PSUs
#'   partially intersecting the domain contribute correctly.
#'
#' The comparison arms complete a five-arm design-awareness comparison:
#' *Fully-Aware* (`"fa"`; single weighted SuperLearner fit + weighted
#' targeting, clustered design SE), *Partially-Aware* (`"pa"`; same point
#' estimate, weighted SE ignoring clustering), *Non-Aware* (`"na"`;
#' unweighted TMLE, iid SE), and *Fully-Aware-CV* (`"cv"`; internal
#' cross-validation instead of cross-fitting; needs at least two learners).
#' On domain analyses the CV arm fits its nuisances unweighted, like the
#' primary arm (in the default mode; with `nuisance_weights = "survey"` both
#' are survey-weighted) -- but on a whole-sample analysis of a design with
#' globally unique PSU ids, the CV arm uses WEIGHTED nuisances as a
#' simulation foil: it is a deliberately handicapped
#' comparator there, not a recommended estimator. The CV arm's internal CV
#' asks `surveyCV::folds.svy` for PSU-id-clustered folds; when the PSU id
#' variable has fewer distinct values than `inner_cv_folds` (as with NHANES
#' `SDMVPSU`, coded 1--3 within stratum), it falls back to SuperLearner's
#' default row-level CV.
#' Whole-sample analyses of designs whose PSU ids repeat across strata are
#' routed through the domain machinery (with an all-`TRUE` domain), which
#' carries the nesting information; the primary arm is numerically
#' unaffected, and the CV arm then uses its real-data (unweighted)
#' convention.
#'
#' **Scope.** Binary outcome and binary treatment, coded 0/1 (logical is
#' accepted; for a two-level factor the SECOND level is coded 1, with a
#' message -- relevel first if your exposure level is not the second).
#' The primary variance is
#' the with-replacement first-stage (no-FPC) linearization, which is
#' calibrated for the super-population ATE while applying an FPC
#' under-covers. PPS-without-replacement and calibrated/post-stratified
#' designs are out of scope and rejected.
#'
#' **Reproducibility.** All randomness (fold assignment, SuperLearner
#' cross-validation) comes from R's RNG: call `set.seed()` before
#' `svytmle()`. No random numbers are consumed between your `set.seed()`
#' and the engine, and `arms = "all"` runs the arms in a fixed order, so a fit
#' is bit-reproducible given the same seed, data, and package versions (see the
#' package's equivalence tests).
#'
#' @param design a survey design object from [survey::svydesign()] (the FULL
#'   design -- select analytic domains with `subset`, do not pass a
#'   `subset()`-ed design). PPS and calibrated/post-stratified designs are
#'   rejected. A replicate-weight design ([survey::svrepdesign()]) is accepted
#'   and forces `variance = "replicate"`; because it carries no PSU/strata, its
#'   cross-fitting falls back to observation-level (i.i.d.) folds, and the
#'   numerical equivalence with the published analysis (PSU-level) does not apply.
#' @param outcome name of the binary (0/1) outcome column in the design's
#'   variables.
#' @param treatment name of the binary (0/1) treatment column.
#' @param covariates character vector (or one-sided formula) of adjustment
#'   covariate columns. Factors are one-hot encoded; covariates must be
#'   complete on the analytic domain (impute first -- see the vignettes).
#' @param learners SuperLearner library for the nuisance fits. The default
#'   `c("SL.glm", "SL.earth", "SL.glmnet")` requires the `earth` and `glmnet`
#'   packages.
#' @param subset optional analytic-domain selector: a one-sided formula over
#'   the design variables (e.g. `~ age >= 20`) or a full-length logical
#'   vector. Default `NULL` analyses the whole sample.
#' @param arms `"cf"` (default, the recommended estimator), `"all"` (the
#'   five design-awareness arms, in a fixed run order), or a
#'   character subset of `c("fa", "pa", "na", "cv", "cf")`.
#' @param cf_folds target number of cross-fitting folds `V` (default 5;
#'   reduced to the minimum PSUs-per-stratum, never below 2).
#' @param inner_cv_folds folds for the `"cv"` comparison arm's internal CV.
#' @param family outcome family: `"binomial"` (default, the primary binary
#'   risk-difference estimator) or `"gaussian"` for a bounded continuous
#'   outcome (mean difference). The gaussian branch is a separate, **opt-in,
#'   unvalidated** estimator: the outcome is rescaled to `[0, 1]` for the
#'   logistic fluctuation, the treatment model stays binomial, and the Q-side
#'   truncation is skipped. The numerical validation covers only the default
#'   `"binomial"` path.
#' @param variance variance estimator: `"linearization"` (default, the primary
#'   design-based Taylor SE) or `"replicate"`, which keeps the same point
#'   estimate and per-unit influence function but takes the SE (and the
#'   t-reference df) from a replicate-weight design. `"replicate"` supports
#'   `arms` `"cf"` and/or `"fa"` only (the foil arms are linearization
#'   comparisons), and unlocks designs that ship replicate weights (BRFSS,
#'   NHIS-BRR, CCHS, ACS, DHS). The replicate point estimate is validated only
#'   on a linearization design (PSU-level cross-fitting); see `design`.
#' @param replicate_type replicate scheme passed to [survey::as.svrepdesign()]
#'   when `variance = "replicate"` and `design` is a linearization design
#'   (default `"JKn"`, the stratified delete-one-PSU jackknife). Ignored when
#'   `design` already carries replicate weights.
#' @param g_bound truncation bound for the propensity predictions supplied
#'   to targeting by the `"cf"` (out-of-fold) and `"cv"` (full-sample) arms
#'   (default 0.05, i.e. truncation to `[0.05, 0.95]`).
#' @param level confidence level (default 0.95) for the t reference (design
#'   df). `confint()` can re-level a fitted object without refitting (the df
#'   does not depend on the level).
#' @param nuisance_weights `"unweighted"` (default; the published estimator,
#'   valid under sampling ignorability given `covariates`) or `"survey"`
#'   (opt-in): the cross-fitted arm's out-of-fold nuisance fits, and the `"cv"`
#'   arm's full-sample fits, use normalised survey weights, with the
#'   training-fold PSU-selection correction for the cross-fitted arm. Every
#'   learner must honour SuperLearner's `obsWeights`: survey mode stops for
#'   wrappers known to ignore them (`SL.earth` among them; use
#'   `"SL.earth.w"`) and warns for wrappers it cannot confirm. The single-fit
#'   `"fa"`/`"pa"` arms pass the survey weights to SuperLearner in both modes
#'   (a learner that ignores `obsWeights` stays unweighted there too), and the
#'   `"na"` foil stays unweighted. The mode is recorded in the fitted object.
#'
#' @return An object of class `svytmle`: a list whose main element
#'   `results` is a data frame with one row per arm (`method`, the ATE `b`,
#'   design-based `se`, design `df`, and `lcl`/`ucl` from the t reference).
#'   `coef()`, `confint()`, `print()` and `summary()` methods report the
#'   primary cross-fitted arm as the primary estimate when present
#'   (`confint(fit, parm = "cf")` accepts the arm codes or the method
#'   labels). Diagnostics (targeting epsilon magnitudes, propensity ranges,
#'   effective V) are in `$diagnostics`; the per-arm targeted means and
#'   influence functions needed for relative effects are in
#'   `$arm_components` (see [riskratio()] / [oddsratio()]).
#'
#' @references Karim, M. E. (2026). Cross-Fitted Survey-Weighted TMLE with
#'   Design-Based Variance for Causal Machine Learning. *Submitted.*
#'
#' @seealso [svytmle_mi()] for multiple-imputation (Rubin) pooling;
#'   [svyaipw()] for the AIPW comparator; [riskratio()] / [oddsratio()] for
#'   relative effects from a fit; [make_population()] and [draw_sample()] for
#'   the simulation DGP; the package vignettes for the NHANES analyses.
#'
#' @export
#' @examples
#' \donttest{
#' pop <- make_population("standard", "simple", truth_M = 1e4L)
#' obs <- draw_sample(pop, sample_seed = 7L)
#' des <- survey::svydesign(ids = ~cluster, strata = ~strata,
#'                          weights = ~weight, data = obs)
#' set.seed(1)
#' fit <- svytmle(des, outcome = "Y", treatment = "A",
#'                covariates = c("L1", "L2", "L3", "L4"),
#'                learners = "SL.glm")   # single-learner library for speed
#' fit
#' }
svytmle <- function(design, outcome, treatment, covariates,
                    learners = c("SL.glm", "SL.earth", "SL.glmnet"),
                    subset = NULL,
                    arms = "cf",
                    family = c("binomial", "gaussian"),
                    variance = c("linearization", "replicate"),
                    replicate_type = "JKn",
                    cf_folds = 5L,
                    inner_cv_folds = 5L,
                    g_bound = 0.05,
                    level = 0.95,
                    nuisance_weights = c("unweighted", "survey")) {
  family   <- match.arg(family)
  variance <- match.arg(variance)
  nuisance_weights <- match.arg(nuisance_weights)
  # a replicate-weight design can only yield a replicate variance
  if (inherits(design, "svyrep.design")) variance <- "replicate"
  if (!is.numeric(level) || length(level) != 1 || level <= 0 || level >= 1)
    stop("`level` must be a single number in (0, 1).", call. = FALSE)
  if (!is.numeric(g_bound) || length(g_bound) != 1 || g_bound <= 0 || g_bound >= 0.5)
    stop("`g_bound` must be a single number in (0, 0.5).", call. = FALSE)

  eng_arms <- if (identical(arms, "all")) c("fa", "pa", "na", "cv", "cf")
              else match.arg(arms, c("fa", "pa", "na", "cv", "cf"),
                             several.ok = TRUE)
  if (variance == "replicate") {
    bad <- setdiff(eng_arms, c("fa", "cf"))
    if (length(bad))
      stop("variance = \"replicate\" supports arms \"cf\" and \"fa\" only (the ",
           "foil arms ", paste(sQuote(bad), collapse = ", "), " are ",
           "linearization-variance comparisons). Use arms = \"cf\" and/or \"fa\".",
           call. = FALSE)
  }
  if ("cv" %in% eng_arms && length(learners) < 2) {
    if (all(eng_arms == "cv"))
      stop("arms = \"cv\" needs a multi-learner library (the engine skips the ",
           "internal-CV comparison arm for a single learner); add learners or ",
           "request other arms.", call. = FALSE)
    warning("the Fully-Aware-CV comparison arm needs a multi-learner library; ",
            "it will be skipped (as in the reference engine).", call. = FALSE)
  }
  .check_learners(learners)
  .check_nuisance_learners(learners, nuisance_weights)
  if (identical(nuisance_weights, "survey") && !any(c("cf", "cv") %in% eng_arms))
    warning("nuisance_weights = \"survey\" affects only the \"cf\" and \"cv\" arms; ",
            "it has no effect on the requested arms.", call. = FALSE)

  prep <- .prepare_engine_input(design, outcome, treatment, covariates,
                                subset = subset, family = family,
                                allow_replicate = (variance == "replicate"))
  ext <- prep$ext; inpop <- prep$inpop; rows <- prep$rows; wnames <- prep$wnames

  # ---- the primary engine (no RNG consumed before this call) ----
  r <- run_estimators(prep$obs, learners = learners, V_cf = cf_folds,
                      inner_cv_folds = inner_cv_folds, g_oof_bound = g_bound,
                      W_cols = wnames, nest = TRUE, inpop = inpop,
                      family = family, arms = eng_arms,
                      nuisance_weights = nuisance_weights)
  if (is.null(r$results))
    stop("no estimator arm was run (requested: ",
         paste(eng_arms, collapse = ", "), ").", call. = FALSE)

  rr <- r$results
  if (variance == "replicate") {
    # swap the linearization SE for the replicate-weight SE of each arm's EIF
    # (the point estimate is unchanged); df becomes the replicate degrees of freedom.
    rep_des <- if (inherits(design, "svyrep.design")) design
               else as.svrepdesign(design, type = replicate_type)
    for (k in seq_len(nrow(rr))) {
      comp <- r$diagnostics$arms[[rr$method[k]]]
      sr   <- .se_replicate(comp$eif1 - comp$eif0, rep_des, inpop)
      rr$se[k] <- sr$se; rr$df[k] <- sr$df
    }
  }
  crit <- qt(1 - (1 - level) / 2, pmax(1, rr$df))   # t reference
  rr$lcl <- rr$b - crit * rr$se
  rr$ucl <- rr$b + crit * rr$se
  rownames(rr) <- NULL

  structure(list(
    results     = rr,
    diagnostics = r$diagnostics$drow,
    g_fa        = r$diagnostics$g_fa,
    g_cf        = r$diagnostics$g_cf,
    # per-arm targeted means + influence functions for riskratio()/oddsratio()
    # (engine stores Fully-Aware and Fully-Aware-CF when those arms run), with
    # the full-length design columns + domain selector delta_rr_or() needs.
    arm_components = r$diagnostics$arms,
    design_cols = list(strata = ext$strata, cluster = ext$cluster, weight = ext$weight),
    inpop       = inpop,
    nest        = TRUE,
    family      = family,
    estimator   = "tmle",
    variance    = variance,
    replicate_type = if (variance != "replicate") NA_character_
                     else if (inherits(design, "svyrep.design")) "design"
                     else replicate_type,
    call        = match.call(),
    outcome     = outcome,
    treatment   = treatment,
    covariates  = prep$covariates,
    covariate_columns = wnames,
    learners    = learners,
    arms        = eng_arms,
    level       = level,
    g_bound     = g_bound,
    cf_folds    = cf_folds,
    nuisance_weights = nuisance_weights,
    n           = prep$n_full,
    n_domain    = length(rows),
    n_psu       = length(unique(paste(ext$strata[rows], ext$cluster[rows]))),
    n_strata    = length(unique(ext$strata[rows])),
    extraction  = ext$source
  ), class = "svytmle")
}
