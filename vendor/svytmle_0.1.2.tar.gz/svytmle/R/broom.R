# =====================================================================
# broom.R — tidy()/glance() methods so svytmle fits compose with the
# modelsummary / gtsummary / metafor ecosystem. Re-exports the generics from
# `generics` (a tiny, base-like dependency) so no `broom` import is needed.
# =====================================================================

#' @importFrom generics tidy
#' @export
generics::tidy

#' @importFrom generics glance
#' @export
generics::glance

#' Tidy / glance methods for survey-TMLE fits
#'
#' `tidy()` returns one row per estimator arm (`term`, `estimate`, `std.error`,
#' `df`, and the confidence bounds); `glance()` returns a one-row model summary.
#' These let [svytmle()] / [svytmle_mi()] / [svyaipw()] objects feed
#' `modelsummary`, `gtsummary`, `metafor`, and `purrr::map_dfr()` pipelines.
#'
#' @param x a fitted [svytmle()], [svytmle_mi()], or [svyaipw()] object.
#' @param conf.int logical; include `conf.low`/`conf.high` (default `TRUE`).
#' @param ... unused.
#' @return `tidy()`: a data frame, one row per arm. `glance()`: a one-row data frame.
#' @name svytmle_broom
#' @examples
#' \donttest{
#' pop <- make_population("standard", "simple", truth_M = 1e4L)
#' des <- survey::svydesign(ids = ~cluster, strata = ~strata, weights = ~weight,
#'                          data = draw_sample(pop, sample_seed = 7L))
#' set.seed(1)
#' fit <- svytmle(des, "Y", "A", c("L1", "L2", "L3", "L4"), learners = "SL.glm")
#' tidy(fit)
#' glance(fit)
#' }
NULL

#' @rdname svytmle_broom
#' @export
tidy.svytmle <- function(x, conf.int = TRUE, ...) {
  rr  <- x$results
  out <- data.frame(term = rr$method, estimate = rr$b, std.error = rr$se,
                    df = rr$df, stringsAsFactors = FALSE)
  if (isTRUE(conf.int)) { out$conf.low <- rr$lcl; out$conf.high <- rr$ucl }
  if (!is.null(rr$fmi))    out$fmi    <- rr$fmi      # MI fits
  if (!is.null(rr$se_jkn)) out$se_jkn <- rr$se_jkn   # AIPW fits
  out
}

#' @rdname svytmle_broom
#' @export
glance.svytmle <- function(x, ...) {
  g <- function(f) if (is.null(x[[f]])) NA else x[[f]]
  i <- .primary_row(x)
  data.frame(
    estimator = if (identical(x$estimator, "aipw")) "AIPW" else "TMLE",
    family    = if (is.null(x$family)) "binomial" else x$family,
    primary   = x$results$method[i],
    n         = g("n"),
    n_domain  = g("n_domain"),
    n_psu     = g("n_psu"),
    n_strata  = g("n_strata"),
    n_imputations = g("M"),
    level     = x$level,
    stringsAsFactors = FALSE)
}
