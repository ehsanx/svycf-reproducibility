# =====================================================================
# benchmark.R — variance-method and compute benchmarks (Web Tables S35/S36)
#
# Two user-facing benchmarks that accompany the paper:
#   variance_methods()  — S35: compare the design-based linearization SE with
#                         replicate-weight methods (and an optional full-refit
#                         cluster bootstrap) on the SAME fitted influence
#                         function; reports validity (SE, SE ratio, CI) and cost
#                         (seconds) per route.
#   benchmark_compute()  — S36: time the wall-clock + CPU cost of the estimator
#                         variants (the design-awareness arms, survey AIPW, the
#                         risk-ratio/odds-ratio delta post-processor, and a
#                         deployable Super Learner library).
#
# Neither touches the estimation engine (engine.R), so the bitwise equivalence
# with the paper's as-run pipeline is unaffected.
# =====================================================================

# map a displayed arm name to its engine code (for re-fitting in the bootstrap)
.arm_code <- function(arm) {
  switch(arm,
    "Fully-Aware"     = "fa", "Partially-Aware" = "pa", "Non-Aware" = "na",
    "Fully-Aware-CV"  = "cv", "Fully-Aware-CF"  = "cf",
    stop("unknown arm \"", arm, "\".", call. = FALSE))
}

# full-refit cluster bootstrap: resample PSUs within strata (with replacement,
# relabelled unique so nest = TRUE treats duplicates as distinct), rebuild the
# design + data, and re-run the estimator -- so every nuisance is re-cross-fit.
# Returns the bootstrap SE of the arm's point estimate. Needs the original
# `design` (the fit does not store the data).
.bootstrap_refit <- function(object, design, arm, B, seed = NULL) {
  if (is.null(design))
    stop("the full-refit bootstrap (B > 0) needs the original `design` passed ",
         "to svytmle(); call variance_methods(fit, design = your_design, B = ...).",
         call. = FALSE)
  if (!is.null(seed)) set.seed(seed)
  vars <- design$variables
  dc   <- object$design_cols
  str  <- dc$strata; psu <- dc$cluster
  subset_spec <- object$call$subset            # re-evaluated on each resample
  code <- .arm_code(arm)
  t0   <- proc.time()[3]
  bvals <- rep(NA_real_, B)
  for (b in seq_len(B)) {
    rows <- integer(0); newpsu <- integer(0); nxt <- 0L
    for (s in unique(str)) {
      ps   <- unique(psu[str == s]); mh <- length(ps)
      samp <- if (mh < 2L) ps else sample(ps, mh, replace = TRUE)
      for (p in samp) {
        ix  <- which(str == s & psu == p); nxt <- nxt + 1L
        rows <- c(rows, ix); newpsu <- c(newpsu, rep.int(nxt, length(ix)))
      }
    }
    bd <- vars[rows, , drop = FALSE]
    bd$.bstrata <- str[rows]; bd$.bpsu <- newpsu; bd$.bweight <- dc$weight[rows]
    bdes <- survey::svydesign(ids = ~.bpsu, strata = ~.bstrata,
                              weights = ~.bweight, data = bd, nest = TRUE)
    fb <- tryCatch(
      svytmle(bdes, object$outcome, object$treatment, object$covariates,
              learners = object$learners, arms = code, family = object$family,
              subset = subset_spec, cf_folds = object$cf_folds,
              g_bound = object$g_bound, level = object$level,
              # refit in the fitted object's nuisance mode (NULL = a pre-0.1.2 object)
              nuisance_weights = if (is.null(object$nuisance_weights)) "unweighted" else object$nuisance_weights),
      error = function(e) NULL)
    if (!is.null(fb)) bvals[b] <- fb$results$b[match(arm, fb$results$method)]
  }
  bv <- bvals[is.finite(bvals)]
  list(se = if (length(bv) > 1L) stats::sd(bv) else NA_real_,
       df = length(bv) - 1L, seconds = proc.time()[3] - t0,
       n_ok = length(bv), values = bv)
}

#' Compare survey variance methods on a fitted svytmle
#'
#' Recomputes the standard error of a fitted [svytmle()] point estimate under
#' several survey variance methods, **all on the same fitted influence
#' function**: the design-based Taylor-series linearization (the package
#' default), a set of replicate-weight methods (delete-one-PSU jackknife,
#' balanced repeated replication, Fay's BRR, and the Rao--Wu--Yue
#' subbootstrap), and -- optionally -- a full-refit cluster bootstrap that
#' re-cross-fits every nuisance on resampled primary sampling units (the only
#' route that propagates nuisance-estimation uncertainty, and far more
#' expensive).
#'
#' On a real survey the design-based linearization standard error typically
#' agrees with the replicate methods to within Monte Carlo error, at a tiny
#' fraction of the full-refit bootstrap's cost.
#'
#' @param object a fitted `svytmle` object that includes the requested `arm`
#'   (e.g. a default `svytmle()` fit, which runs the cross-fitted arm).
#' @param design the original `survey::svydesign` passed to [svytmle()]. Only
#'   required for the full-refit `"bootstrap"` method (`B > 0`); every other
#'   method is computed from `object` alone.
#' @param methods variance methods to compute, any of `"linearization"`,
#'   `"jackknife"`, `"BRR"`, `"Fay"`, `"subbootstrap"`, `"bootstrap"`. Methods
#'   that the design cannot support (e.g. BRR off a non-two-per-stratum design)
#'   are skipped with a warning.
#' @param arm which arm's influence function to use; defaults to the primary
#'   cross-fitted arm `"Fully-Aware-CF"`.
#' @param B number of full-refit bootstrap replicates (`0` skips it). The
#'   bootstrap re-cross-fits all nuisances per replicate and is slow.
#' @param fay_rho Fay's BRR parameter (default 0.3, the NCHS/NHANES convention).
#' @param subbootstrap_replicates number of Rao--Wu--Yue subbootstrap replicates.
#' @param level confidence level for the reported intervals (default: the fit's).
#' @param seed optional integer seed for the replicate/bootstrap randomness.
#' @return a data.frame, one row per method, with columns `method`, `refit`
#'   (whether nuisances are refit), `se`, `se_ratio` (relative to the
#'   linearization SE), `ci_lo`, `ci_hi`, `df`, and `seconds`. The point
#'   estimate and the chosen arm are attached as attributes `"estimate"` and
#'   `"arm"`.
#' @seealso [benchmark_compute()] for the per-estimator compute benchmark.
#' @examples
#' \donttest{
#' pop <- make_population("standard", "simple", truth_M = 2e4L)
#' obs <- draw_sample(pop, sample_seed = 7L)
#' des <- survey::svydesign(ids = ~cluster, strata = ~strata,
#'                          weights = ~weight, data = obs)
#' set.seed(1)
#' fit <- svytmle(des, "Y", "A", c("L1", "L2", "L3", "L4"))
#' variance_methods(fit, seed = 1)            # the frozen-EIF routes (fast)
#' }
#' \dontrun{
#' # the full-refit cluster bootstrap re-cross-fits every nuisance (slow):
#' variance_methods(fit, design = des, methods = "bootstrap", B = 200, seed = 1)
#' }
#' @export
variance_methods <- function(object, design = NULL,
                             methods = c("linearization", "jackknife", "BRR",
                                         "Fay", "subbootstrap"),
                             arm = "Fully-Aware-CF",
                             B = 0L, fay_rho = 0.3,
                             subbootstrap_replicates = 200L,
                             level = NULL, seed = NULL) {
  if (!inherits(object, "svytmle"))
    stop("`object` must be a fitted svytmle object.", call. = FALSE)
  methods <- match.arg(methods, c("linearization", "jackknife", "BRR", "Fay",
                                  "subbootstrap", "bootstrap"), several.ok = TRUE)
  if (is.null(level)) level <- object$level
  if (!is.null(seed)) set.seed(seed)

  comp <- object$arm_components[[arm]]
  if (is.null(comp))
    stop("arm \"", arm, "\" is not in this fit (available: ",
         paste(names(object$arm_components), collapse = ", "),
         "). Re-run svytmle() with that arm.", call. = FALSE)
  eif   <- comp$eif1 - comp$eif0            # contrast influence function (domain rows)
  bhat  <- comp$psi1 - comp$psi0            # the arm's point estimate
  inpop <- object$inpop
  dc    <- object$design_cols
  nest  <- isTRUE(object$nest)
  full  <- data.frame(.strata = dc$strata, .cluster = dc$cluster, .weight = dc$weight)
  lin_des <- survey::svydesign(ids = ~.cluster, strata = ~.strata,
                               weights = ~.weight, data = full, nest = nest)

  # linearization SE recomputed from the EIF (independent of the fit's variance
  # setting); used as the ratio base.
  lin <- .se_des(eif, dc$strata, dc$cluster, dc$weight, TRUE, nest = nest, inpop = inpop)
  lin_se <- lin$se

  rep_se <- function(type, ...) {
    t0 <- proc.time()[3]
    out <- tryCatch(
      .se_replicate(eif, survey::as.svrepdesign(lin_des, type = type, ...), inpop),
      error = function(e) {
        warning("variance method \"", type, "\" not available for this design: ",
                conditionMessage(e), call. = FALSE)
        list(se = NA_real_, df = NA_real_)
      })
    out$seconds <- proc.time()[3] - t0
    out
  }

  rows <- list()
  add  <- function(method, refit, se, df, secs)
    rows[[length(rows) + 1L]] <<- data.frame(
      method = method, refit = refit, se = se, df = df, seconds = secs,
      stringsAsFactors = FALSE)

  if ("linearization" %in% methods) {
    t0 <- proc.time()[3]
    s  <- .se_des(eif, dc$strata, dc$cluster, dc$weight, TRUE, nest = nest, inpop = inpop)
    add("Linearization (TSL)", "No", s$se, s$df, proc.time()[3] - t0)
  }
  if ("jackknife" %in% methods)    { r <- rep_se("JKn"); add("Delete-one-PSU jackknife", "No", r$se, r$df, r$seconds) }
  if ("BRR" %in% methods)          { r <- rep_se("BRR"); add("Balanced repeated replication", "No", r$se, r$df, r$seconds) }
  if ("Fay" %in% methods)          { r <- rep_se("Fay", fay.rho = fay_rho); add(sprintf("Fay's BRR (rho = %.2g)", fay_rho), "No", r$se, r$df, r$seconds) }
  if ("subbootstrap" %in% methods) { r <- rep_se("subbootstrap", replicates = subbootstrap_replicates); add("Rao-Wu-Yue subbootstrap", "No", r$se, r$df, r$seconds) }
  if ("bootstrap" %in% methods) {
    if (B > 0L) { bs <- .bootstrap_refit(object, design, arm, B); add("Full-refit cluster bootstrap", "Yes", bs$se, bs$df, bs$seconds) }
    else warning("\"bootstrap\" requested but B = 0; the full-refit bootstrap is skipped.",
                 call. = FALSE)
  }

  res <- do.call(rbind, rows)
  res$se_ratio <- res$se / lin_se
  crit <- stats::qt(1 - (1 - level) / 2, pmax(1, res$df))
  res$ci_lo <- bhat - crit * res$se
  res$ci_hi <- bhat + crit * res$se
  res <- res[, c("method", "refit", "se", "se_ratio", "ci_lo", "ci_hi", "df", "seconds")]
  res$seconds <- round(res$seconds, 3)
  rownames(res) <- NULL
  attr(res, "estimate") <- bhat
  attr(res, "arm") <- arm
  res
}

#' Per-estimator compute benchmark
#'
#' Times the wall-clock and CPU cost of the estimator variants on one analysis:
#' the design-awareness arms (a single five-arm [svytmle()] call), survey-weighted
#' AIPW ([svyaipw()]), the risk-ratio/odds-ratio delta-method post-processor
#' ([riskratio()]/[oddsratio()] on a cross-fitted fit, no refit), and -- if a
#' richer library is supplied -- a deployable Super Learner. Each variant is run
#' once and timed with [system.time()]; the engine is unchanged.
#'
#' @param design a `survey::svydesign`.
#' @param outcome,treatment,covariates passed to [svytmle()] / [svyaipw()].
#' @param learners the Super Learner library for the primary variants.
#' @param deploy_learners an optional richer library timed as the "deployable"
#'   row (e.g. adding `"SL.ranger"`, `"SL.xgboost"`); `NULL` omits that row.
#' @param family `"binomial"` (default) or `"gaussian"`.
#' @param subset optional domain selector passed through to the estimators.
#' @param what which variants to time: any of `"arms"`, `"aipw"`, `"rr_or"`,
#'   `"deployable"`.
#' @param cf_folds cross-fitting folds.
#' @param seed optional integer seed (set once before the benchmark).
#' @return a data.frame with one row per timed variant: `estimator`, `wall_s`,
#'   `cpu_s`, and `ok` (whether it completed).
#' @seealso [variance_methods()] for the variance-method benchmark.
#' @examples
#' \donttest{
#' pop <- make_population("standard", "simple", truth_M = 2e4L)
#' obs <- draw_sample(pop, sample_seed = 7L)
#' des <- survey::svydesign(ids = ~cluster, strata = ~strata,
#'                          weights = ~weight, data = obs)
#' benchmark_compute(des, "Y", "A", c("L1", "L2", "L3", "L4"),
#'                   learners = "SL.glm", what = c("arms", "aipw", "rr_or"),
#'                   seed = 1)
#' }
#' @export
benchmark_compute <- function(design, outcome, treatment, covariates,
                              learners = c("SL.glm", "SL.earth", "SL.glmnet"),
                              deploy_learners = NULL, family = "binomial",
                              subset = NULL,
                              what = c("arms", "aipw", "rr_or", "deployable"),
                              cf_folds = 5L, seed = NULL) {
  what <- match.arg(what, several.ok = TRUE)
  if (!is.null(seed)) set.seed(seed)
  timed <- function(label, expr) {
    st <- system.time(v <- tryCatch(eval.parent(substitute(expr)),
                                    error = function(e) {
                                      warning(label, " failed: ", conditionMessage(e),
                                              call. = FALSE); NULL }))
    data.frame(estimator = label,
               wall_s = round(st[["elapsed"]], 3),
               cpu_s  = round(st[["user.self"]] + st[["sys.self"]], 3),
               ok = !is.null(v), stringsAsFactors = FALSE)
  }
  rows <- list()
  if ("arms" %in% what)
    rows[[length(rows) + 1L]] <- timed(
      "Five-arm TMLE (Non-/Partially-/Fully-Aware, CV, CF)",
      svytmle(design, outcome, treatment, covariates, learners = learners,
              arms = "all", family = family, subset = subset, cf_folds = cf_folds))
  if ("aipw" %in% what)
    rows[[length(rows) + 1L]] <- timed(
      "Survey-weighted AIPW (single- + cross-fit)",
      svyaipw(design, outcome, treatment, covariates, learners = learners,
              subset = subset))
  if ("rr_or" %in% what)
    rows[[length(rows) + 1L]] <- timed(
      "Risk ratio + odds ratio (delta on CF arm)",
      { f <- svytmle(design, outcome, treatment, covariates, learners = learners,
                     arms = "cf", family = family, subset = subset, cf_folds = cf_folds)
        list(riskratio(f), oddsratio(f)) })
  if ("deployable" %in% what && !is.null(deploy_learners))
    rows[[length(rows) + 1L]] <- timed(
      "Deployable Super Learner (CF)",
      svytmle(design, outcome, treatment, covariates, learners = deploy_learners,
              arms = "cf", family = family, subset = subset, cf_folds = cf_folds))
  out <- do.call(rbind, rows)
  out$total_s <- out$wall_s
  rownames(out) <- NULL
  out
}
