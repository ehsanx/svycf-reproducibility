# svytmle

[![License: GPL v3](https://img.shields.io/badge/License-GPLv3-blue.svg)](https://www.gnu.org/licenses/gpl-3.0)
[![R](https://img.shields.io/badge/R-%E2%89%A5%204.1-276DC3.svg)](https://www.r-project.org/)

**Survey-weighted, cross-fitted TMLE of the population average treatment
effect (ATE), with a design-based variance, for complex survey data.**

`svytmle()` takes any `survey::svydesign` plus an outcome / treatment /
covariate specification and returns the population ATE (risk difference) with a
design-based (Taylor-series linearization) standard error and a *t*-reference
confidence interval on the design degrees of freedom (#PSUs − #strata). It is
built for the stratified, multistage, unequally-weighted designs of real
surveys (NHANES, BRFSS, NHIS, …), and lets flexible machine-learning nuisance
estimators stay valid by cross-fitting at the level of the first-stage sampling
unit (PSU).

## How the estimator works

- **PSU-level cross-fitting** — folds are whole first-stage sampling units
  (PSUs) nested within strata; within each stratum the balanced cyclic
  fold-size pattern is assigned to PSUs in random order (a 3-PSU stratum
  splits 2–1; with 2 PSUs per stratum this is
  leave-one-PSU-per-stratum-out). This removes the Donsker-class
  complexity restriction on the nuisance learners while respecting the
  dependence unit of the design.
- **Unweighted out-of-fold nuisance fits (default)** — the outcome regression and
  propensity score are fit *without* survey weights (valid under sampling
  ignorability, S ⊥ (A, Y) | C; also avoids weighted-fit separation), and
  predicted out-of-fold. When sampling may be informative given C, pass
  `nuisance_weights = "survey"` (0.1.2+) to fit them with the survey weights,
  corrected for each training fold's PSU selection.
- **Propensity truncation** — out-of-fold propensities truncated to
  [0.05, 0.95].
- **Survey weights only at targeting and variance** — targeting uses the
  `tmle` engine's arm-specific two-parameter logistic fluctuation
  (ε₀, ε₁) on the clever covariates (H0W, H1W) with the survey weights as
  observation weights.
- **Design-based variance** — the per-unit influence function is
  reconstructed *unweighted* from the targeted nuisances (avoiding
  double-weighting), and `survey::svymean` supplies the stratified-cluster
  linearization variance; CIs use *t* with df = #PSU − #strata.
- **Domain (sub-population) analyses** — with `subset = ~ ...`, nuisances are
  fit on the domain while the variance is computed on the full design then
  subset (subset the design, not the data).

> **Name disambiguation:** `svytmle` is not `survtmle` (TMLE for *survival*
> outcomes) and not `tmle` (i.i.d.-data TMLE; used internally here for the
> targeting step only).

## Installation

```r
# install.packages(c("survey", "SuperLearner", "surveyCV", "tmle",
#                    "earth", "glmnet"))
# remotes::install_github("ehsanx/svytmle")   # once public
devtools::install("path/to/svytmle", build_vignettes = TRUE)
```

Not yet on CRAN.

## Quick start

```r
library(svytmle)

# estimate the ATE on your own survey data:
des <- survey::svydesign(ids = ~psu, strata = ~stratum, weights = ~w,
                         data = mydata)
set.seed(1)
fit <- svytmle(des, outcome = "Y", treatment = "A",
               covariates = c("age", "sex", "bmi"))
fit            # cross-fitted ATE + design-based 95% t CI
summary(fit)   # adds targeting / overlap diagnostics
tidy(fit)      # a tidy one-row data frame

# the full five-arm comparison, design-naive through fully design-aware:
svytmle(des, "Y", "A", c("age", "sex", "bmi"), arms = "all")$results
```

No survey data handy? A built-in stratified two-stage data-generating process
with a known truth gives a self-contained example:

```r
pop <- make_population("standard", "simple", truth_M = 2e4L)
obs <- draw_sample(pop, sample_seed = 7L)
des <- survey::svydesign(ids = ~cluster, strata = ~strata,
                         weights = ~weight, data = obs)
svytmle(des, "Y", "A", c("L1", "L2", "L3", "L4"))
```

The default learner library is `c("SL.glm", "SL.earth", "SL.glmnet")`; pass any
SuperLearner library via `learners`. Also available: risk ratios / odds ratios
(`riskratio()`, `oddsratio()`), continuous outcomes (`family = "gaussian"`),
multiple imputation (`svytmle_mi()`), replicate-weight variance
(`variance = "replicate"`, accepting a `svrepdesign` directly), overlap /
design-effect diagnostics (`overlap()`, `deff()`), and a survey-weighted AIPW
comparator (`svyaipw()`).

## Variance-method and compute benchmarks

`variance_methods()` compares the design-based linearization SE with
replicate-weight methods (delete-one-PSU jackknife, BRR, Fay's BRR, Rao–Wu–Yue
subbootstrap) on the *same* fitted influence function — and, optionally, a
full-refit cluster bootstrap. `benchmark_compute()` times the estimator
variants.

```r
fit <- svytmle(des, "Y", "A", covariates)
variance_methods(fit)                                     # SE, SE-ratio, CI, timing
variance_methods(fit, design = des, methods = "bootstrap", B = 200)
benchmark_compute(des, "Y", "A", covariates)              # per-estimator wall/CPU
```

## Vignettes

| Vignette | Content |
|---|---|
| `svytmle-simulation` | A worked example on the built-in simulation DGP (known truth). |
| `nhanes-E1-sleep-obesity` | Short sleep → obesity (a stable, well-overlapped example). |
| `nhanes-E2-food-insecurity-depression` | Food insecurity → depression (weights change the magnitude). |
| `nhanes-E3-ecig-hypertension` | E-cigarettes → hypertension (significance changes at the weighting step). |
| `nhanes-E4-gdm-hypertension` | GDM history → hypertension (rare exposure; the truncation floor binds). |

The NHANES vignettes are precomputed (CRAN-safe) and show how to rebuild the
analytic frames from public NHANES files via `nhanesA`.

## Validation and reproducibility

A fit is deterministic given `set.seed()` immediately before `svytmle()`. The
estimator is numerically validated against the published analysis of
Karim (2026): equivalence checks in `inst/equivalence/` confirm the package
reproduces that paper's simulation and NHANES results bit-for-bit at a fixed
seed, and the test suite re-checks them on every run (see
`inst/equivalence/README.md`).

## Methods reference

Karim, M. E. (2026). *Cross-Fitted Survey-Weighted TMLE with Design-Based
Variance for Causal Machine Learning.* Manuscript submitted for publication.
Code: <https://github.com/ehsanx/Survey-TMLE-codes>. Run `citation("svytmle")`
for the formatted entry.

## License

GPL (>= 3).
